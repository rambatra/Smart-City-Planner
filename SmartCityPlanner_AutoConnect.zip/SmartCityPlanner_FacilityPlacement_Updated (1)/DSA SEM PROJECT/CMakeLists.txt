cmake_minimum_required(VERSION 3.14)
project(SmartCityPlannerEngine VERSION 1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_executable(SmartCityPlannerServer main.cpp)

if(WIN32)
    target_link_libraries(SmartCityPlannerServer PRIVATE ws2_32)
endif()
