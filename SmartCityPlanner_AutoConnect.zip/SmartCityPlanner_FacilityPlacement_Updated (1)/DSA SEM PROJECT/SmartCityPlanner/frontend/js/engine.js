// ============================================================================
// Built-in DSA Engine (JavaScript port of main.cpp)
// ----------------------------------------------------------------------------
// Used automatically when the C++ server (port 18080) is not running, so the
// project works on ANY laptop just by opening index.html.
// It implements the SAME data structures and algorithms as main.cpp and returns
// the SAME JSON shapes:
//   * Weighted undirected graph (adjacency list) + Map (hash table) for O(1) lookup
//   * Custom Binary Min-Heap (siftUp / siftDown)  - no library priority queue
//   * Dijkstra's shortest path  O((V+E) log V) with predecessor path rebuild
//   * BFS connectivity / connected components  O(V+E)
//   * Alternative-route discovery by edge exclusion
//   * Max-heap ranking of candidate sites + Haversine distance
// ============================================================================

class MinHeap {
  // "less" decides priority: less(a,b) === true means a comes out before b.
  constructor(less) { this.h = []; this.less = less || ((a, b) => a < b); }
  get size() { return this.h.length; }
  empty() { return this.h.length === 0; }
  push(v) { this.h.push(v); this._up(this.h.length - 1); }
  top() { return this.h[0]; }
  pop() {
    if (!this.h.length) return;
    const last = this.h.pop();
    if (this.h.length) { this.h[0] = last; this._down(0); }
  }
  _up(i) {
    const h = this.h;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this.less(h[i], h[p])) { [h[i], h[p]] = [h[p], h[i]]; i = p; } else break;
    }
  }
  _down(i) {
    const h = this.h, n = h.length;
    for (;;) {
      let s = i; const l = 2 * i + 1, r = 2 * i + 2;
      if (l < n && this.less(h[l], h[s])) s = l;
      if (r < n && this.less(h[r], h[s])) s = r;
      if (s === i) break;
      [h[i], h[s]] = [h[s], h[i]]; i = s;
    }
  }
}

class CityGraph {
  constructor() {
    this.nodes = new Map();   // hash table: id -> location
    this.adj = new Map();     // adjacency list: id -> [{roadId,to,weight,blocked}]
  }
  addLocation(loc) {
    this.nodes.set(loc.id, loc);
    if (!this.adj.has(loc.id)) this.adj.set(loc.id, []);
  }
  addRoad(roadId, u, v, km, blocked) {
    if (!this.nodes.has(u) || !this.nodes.has(v)) return;
    if (!(km >= 0)) return; // Dijkstra needs non-negative weights
    this.adj.get(u).push({ roadId, to: v, weight: km, blocked: !!blocked });
    this.adj.get(v).push({ roadId, to: u, weight: km, blocked: !!blocked });
  }
  has(id) { return this.nodes.has(id); }

  static haversineKm(lat1, lng1, lat2, lng2) {
    const R = 6371.0, rad = Math.PI / 180;
    const dLat = (lat2 - lat1) * rad, dLng = (lng2 - lng1) * rad;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  // BFS: connectivity + number of connected components, ignoring blocked roads
  analyzeConnectivityBFS() {
    const total = this.nodes.size;
    const visited = new Set();
    let components = 0, reachableFromFirst = 0;
    for (const start of this.nodes.keys()) {
      if (visited.has(start)) continue;
      components++;
      let count = 0;
      const q = [start]; let head = 0;      // array used as a FIFO queue
      visited.add(start);
      while (head < q.length) {
        const u = q[head++]; count++;
        for (const e of this.adj.get(u) || []) {
          if (e.blocked || visited.has(e.to)) continue;
          visited.add(e.to); q.push(e.to);
        }
      }
      if (components === 1) reachableFromFirst = count;
    }
    return { connected: components === 1, reachableNodes: reachableFromFirst, totalNodes: total, components };
  }

  // Dijkstra with the custom binary min-heap
  dijkstra(startId, endId, ignoreRoadId = "") {
    const res = { found: false, totalKm: 0, visitedNodes: 0, path: [] };
    if (!this.has(startId) || !this.has(endId)) return res;
    const dist = new Map(), parent = new Map();
    for (const id of this.nodes.keys()) dist.set(id, Infinity);
    const heap = new MinHeap((a, b) => a.dist < b.dist);
    dist.set(startId, 0);
    heap.push({ dist: 0, id: startId });
    while (!heap.empty()) {
      const cur = heap.top(); heap.pop();
      if (cur.dist > dist.get(cur.id)) continue;
      res.visitedNodes++;
      if (cur.id === endId) break;
      for (const e of this.adj.get(cur.id) || []) {
        if (e.blocked) continue;
        if (ignoreRoadId && e.roadId === ignoreRoadId) continue;
        const nd = dist.get(cur.id) + e.weight;
        if (nd < dist.get(e.to)) {
          dist.set(e.to, nd); parent.set(e.to, cur.id);
          heap.push({ dist: nd, id: e.to });
        }
      }
    }
    if (dist.get(endId) === Infinity) return res;
    const path = []; let c = endId;
    while (c !== startId) { path.push(this.nodes.get(c)); c = parent.get(c); }
    path.push(this.nodes.get(startId));
    path.reverse();
    res.found = true; res.totalKm = dist.get(endId); res.path = path;
    return res;
  }

  // Alternative routes: re-run Dijkstra excluding each road of the best route
  candidateRoutes(startId, endId) {
    const routes = [];
    const primary = this.dijkstra(startId, endId);
    if (!primary.found) return routes;
    routes.push(primary);
    for (let i = 0; i + 1 < primary.path.length; i++) {
      const u = primary.path[i].id, v = primary.path[i + 1].id;
      let skip = "";
      for (const e of this.adj.get(u) || []) if (!e.blocked && e.to === v) { skip = e.roadId; break; }
      if (!skip) continue;
      const alt = this.dijkstra(startId, endId, skip);
      if (!alt.found) continue;
      const dup = routes.some(r => r.path.length === alt.path.length && r.path.every((p, k) => p.id === alt.path[k].id));
      if (!dup) routes.push(alt);
    }
    routes.sort((a, b) => a.totalKm - b.totalKm);
    return routes.slice(0, 3);
  }

  nearestNodeId(lat, lng) {
    let best = "", bd = Infinity;
    for (const [id, n] of this.nodes) {
      const d = CityGraph.haversineKm(lat, lng, n.lat, n.lng);
      if (d < bd) { bd = d; best = id; }
    }
    return best;
  }
}

function buildGraph(body) {
  const g = new CityGraph();
  (body.locations || []).forEach(l => g.addLocation({ id: l.id, name: l.name, lat: +l.lat, lng: +l.lng, type: l.type }));
  (body.roads || []).forEach(r => g.addRoad(r.id, r.from, r.to, +r.km, r.blocked));
  return g;
}

const r2 = x => Math.round(x * 100) / 100;

const Engine = {
  name: "Built-in JS Engine",

  handle(path, body) {
    switch (path) {
      case "/route/shortest": return this.shortest(body);
      case "/route/compare": return this.compare(body);
      case "/route/connectivity": return buildGraph(body).analyzeConnectivityBFS();
      case "/facility/analyze": return this.facility(body);
      case "/emergency/evacuate": return this.evacuate(body);
      default: throw new Error("Endpoint not found: " + path);
    }
  },

  shortest(b) {
    const res = buildGraph(b).dijkstra(b.origin, b.destination);
    if (!res.found || !res.path.length) return { found: false, totalKm: 0, visitedNodes: res.visitedNodes, path: [], coords: [] };
    return {
      found: true, totalKm: res.totalKm, visitedNodes: res.visitedNodes,
      path: res.path.map(p => ({ id: p.id, name: p.name })),
      coords: res.path.map(p => [p.lat, p.lng])
    };
  },

  compare(b) {
    const routes = buildGraph(b).candidateRoutes(b.origin, b.destination);
    return {
      routes: routes.map((r, i) => ({
        label: i === 0 ? "Optimal (Dijkstra)" : "Alternate #" + i,
        totalKm: r2(r.totalKm), hops: r.path.length - 1, pathNames: r.path.map(p => p.name)
      }))
    };
  },

  facility(b) {
    const g = buildGraph(b), existing = b.existing || [], areas = b.demandAreas || [];
    const heap = new MinHeap((a, c) => a.score > c.score);
    const networkKm = (a, c) => {
      const u = g.nearestNodeId(+a.lat, +a.lng), v = g.nearestNodeId(+c.lat, +c.lng);
      if (u && v) {
        const d = g.dijkstra(u, v);
        if (d.found) {
          const nu = g.nodes.get(u), nv = g.nodes.get(v);
          return CityGraph.haversineKm(+a.lat,+a.lng,nu.lat,nu.lng) + d.totalKm + CityGraph.haversineKm(+c.lat,+c.lng,nv.lat,nv.lng);
        }
      }
      return CityGraph.haversineKm(+a.lat,+a.lng,+c.lat,+c.lng) * 1.25;
    };
    const popMax = Math.max(1, ...areas.map(a => +a.population || 0));
    (b.candidates || []).forEach(c => {
      let nearest = existing.length ? Infinity : 8;
      existing.forEach(ex => nearest = Math.min(nearest, networkKm(c, ex)));
      let weightedPop = 0, coveredPop = 0, accessTotal = 0, accessWeight = 0, coveredAreas = 0;
      areas.forEach(a => {
        let nearestExisting = existing.length ? Infinity : 8;
        existing.forEach(ex => nearestExisting = Math.min(nearestExisting, networkKm(a, ex)));
        const need = Math.min(1, ((+a.population || 0) / popMax) * (0.35 + 0.65 * Math.min(1, nearestExisting / 8)));
        const d = networkKm(c, a);
        weightedPop += (+a.population || 0) * need;
        if (d <= COVERAGE_RADIUS_KM) { coveredPop += (+a.population || 0) * need; coveredAreas++; }
        accessTotal += (1 / (1 + d)) * need;
        accessWeight += need;
      });
      const demand = weightedPop ? Math.min(100, coveredPop / weightedPop * 100) : 0;
      const access = accessWeight ? Math.min(100, accessTotal / accessWeight * 100) : 0;
      const separation = Math.min(100, nearest / 8 * 100);
      const land = Math.min(100, (+c.suitability || 0) * .55 + Math.min(100, (+c.area || 0) / 9000 * 100) * .2 + Math.min(100, (+c.capacity || 0) / 600 * 100) * .25);
      const score = .40 * demand + .25 * access + .20 * separation + .15 * land;
      heap.push({id:c.id,name:c.name,score:r2(score),coverage:r2(demand),coveredAreas,dist:r2(nearest)});
    });
    const ranked=[]; while(!heap.empty()){const x=heap.top();heap.pop();ranked.push({...x,rank:ranked.length+1});}
    return {radiusKm: COVERAGE_RADIUS_KM, totalAreas: areas.length, ranked};
  },

  evacuate(b) {
    const g = buildGraph(b);
    const sLat = +b.shelter.lat, sLng = +b.shelter.lng;
    const target = g.nearestNodeId(sLat, sLng);
    const res = g.dijkstra(b.origin, target);
    if (!res.found || !res.path.length) {
      const s = g.nodes.get(b.origin);
      return { totalKm: CityGraph.haversineKm(s.lat, s.lng, sLat, sLng), hops: 1, coords: [[s.lat, s.lng], [sLat, sLng]] };
    }
    const last = res.path[res.path.length - 1];
    const lastMile = CityGraph.haversineKm(last.lat, last.lng, sLat, sLng);
    return {
      totalKm: res.totalKm + lastMile, hops: res.path.length,
      coords: [...res.path.map(p => [p.lat, p.lng]), [sLat, sLng]]
    };
  }
};
