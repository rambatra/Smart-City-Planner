// ----------------------------------------------------------------------------
// API layer: automatic C++ backend discovery.
// The page works wherever it is opened (VS Code Live Server, double-click, the C++ server itself):
//   * It looks for the C++ server by itself on several addresses and keeps re-checking, so the
//     moment the server is started the page connects, with no refresh and no terminal command.
//   * Facility ranking / adding candidates use the C++ server whenever it is reachable. If it is not
//     running (or an outdated copy is), the identical built-in JavaScript engine is used instead, so
//     the module never stops working on any PC. The result always says which engine did the work.
// ----------------------------------------------------------------------------
const API_BASES = [];
if (location.port === "18080" && location.protocol.startsWith("http")) API_BASES.push("/api");
API_BASES.push("http://localhost:18080/api", "http://127.0.0.1:18080/api");
let API_BASE = API_BASES[0];

// Facility coverage radius (km). MUST match COVERAGE_RADIUS_KM in main.cpp (was 5 km, now 10 km).
const COVERAGE_RADIUS_KM = 10;

const BACKEND = {
  mode: "unknown",          // "cpp" | "js" | "unknown"
  lastFail: 0,
  info: null,               // last /api/health answer from the C++ server
  retryMs: 15000,           // after a failure, wait this long before trying C++ again
  listeners: [],
  label() { return this.mode === "cpp" ? "C++ Engine" : "Built-in Engine"; },
  set(mode) {
    if (mode === this.mode) return;
    this.mode = mode;
    this.listeners.forEach(f => { try { f(mode); } catch (e) { /* ignore */ } });
  },
  onChange(f) { this.listeners.push(f); }
};

async function fetchJson(url, opts, timeoutMs) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { ...opts, signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } finally { clearTimeout(timer); }
}

// Look for the C++ server on every known address; remember the one that answers.
let probing = null;
function probeBackend() {
  if (probing) return probing;
  probing = (async () => {
    let found = false;
    for (const base of API_BASES) {
      try {
        const j = await fetchJson(base + "/health", {}, 1500);
        if (j && j.status === "ok") { API_BASE = base; BACKEND.info = j; found = true; break; }
      } catch (e) { /* try the next address */ }
    }
    if (!found) BACKEND.lastFail = Date.now();
    BACKEND.set(found ? "cpp" : "js");
    return BACKEND.mode;
  })().finally(() => { probing = null; });
  return probing;
}
// A usable C++ server = reachable AND running the current (10 km) build.
const backendIsCurrent = () => !!(BACKEND.info && BACKEND.info.coverageRadiusKm === COVERAGE_RADIUS_KM);
async function ensureBackend() {
  if (BACKEND.mode !== "cpp") await probeBackend();
  return BACKEND.mode === "cpp";
}
// Keep checking in the background so the page connects (or disconnects) automatically.
setInterval(() => { probeBackend(); }, 4000);

async function apiPost(path, body) {
  const tryCpp = BACKEND.mode !== "js" || Date.now() - BACKEND.lastFail > BACKEND.retryMs;
  if (tryCpp) {
    try {
      const out = await fetchJson(API_BASE + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      }, 4000);
      BACKEND.set("cpp");
      return out;
    } catch (e) {
      BACKEND.lastFail = Date.now();
      BACKEND.set("js");
    }
  }
  return Engine.handle(path, body);   // identical algorithms, runs in the browser
}

const API = {
  // Always returns a ranking. res.engine says who produced it; res.note explains a fallback.
  analyzeFacilities: async p => {
    let note = "";
    if (await ensureBackend()) {
      try {
        const out = await fetchJson(API_BASE + "/facility/analyze", {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(p)
        }, 30000);
        if (out && out.radiusKm === COVERAGE_RADIUS_KM) {
          BACKEND.set("cpp"); out.engine = "C++ Engine"; out.note = ""; return out;
        }
        note = "An older C++ server is running (not the 10 km build), so the built-in engine was used. Close it and start START_PROJECT.bat to use your current C++ code.";
      } catch (e) {
        note = "The C++ server did not answer this request, so the built-in engine was used.";
      }
    } else {
      note = "C++ server not detected, so the identical built-in algorithm was used. Start START_PROJECT.bat and this page connects to it automatically.";
    }
    const out = Engine.facility(p);
    out.engine = "Built-in Engine"; out.note = note;
    return out;
  },
  calculateRoute:    p => apiPost("/route/shortest", p),
  compareRoutes:     p => apiPost("/route/compare", p),
  checkConnectivity: p => apiPost("/route/connectivity", p),
  setRoadStatus:     p => apiPost("/route/roads/status", p),
  rankIncidents:     p => apiPost("/emergency/rank", p),
  planEvacuation:    p => apiPost("/emergency/evacuate", p)
};


// Candidate creation: stored by the C++ server (data/candidate_sites.csv) when it is reachable.
// When it is not, the candidate is simply kept in the browser; it is never an error.
async function apiAddCandidate(candidate) {
  if (!(await ensureBackend())) return { ok: true, local: true };
  let out;
  try {
    out = await fetchJson(API_BASE + "/facility/candidate/add", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(candidate)
    }, 7000);
  } catch (e) {
    return { ok: true, local: true };      // old server (404) or connection dropped: keep it locally
  }
  if (!out.ok) throw new Error(out.error || "C++ backend rejected the candidate.");
  BACKEND.set("cpp");
  return out;
}
