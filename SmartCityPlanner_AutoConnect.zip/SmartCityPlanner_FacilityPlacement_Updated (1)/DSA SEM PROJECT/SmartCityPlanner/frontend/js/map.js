// Reusable Leaflet map system.
// Marker letter + colour depends on the TYPE of place: Hospital = H, School = S, Fire station = F ...
const CAT = {
  hospital:[ "#DC2626","H","Hospitals"],
  school:  [ "#2563EB","S","Schools / Universities"],
  fire:    [ "#EA580C","F","Fire stations"],
  clinic:  [ "#0D9488","C","Clinics"],
  candidate:["#7C3AED","+","Candidate sites"],
  shelter: [ "#16A34A","■","Shelters"],
  incident:[ "#B91C1C","!","Incidents"],
  // extra place types used by the Route Optimizer cities
  market:  [ "#D97706","M","Markets / Malls"],
  transport:["#4F46E5","T","Stations / Airports"],
  park:    [ "#65A30D","P","Parks"],
  landmark:[ "#0891B2","L","Landmarks"]
};
const TYPE_LABEL = {hospital:"Hospital",school:"School / University",fire:"Fire station",clinic:"Clinic",market:"Market / Mall",transport:"Station / Airport",park:"Park",landmark:"Landmark"};
const BASE_KINDS = ["hospital","school","fire","clinic","candidate","shelter","incident"];       // original maps
const ROUTE_KINDS = ["hospital","school","fire","market","transport","park","landmark"];          // route map
const RISK = {Low:"#16A34A",Medium:"#F59E0B",High:"#EA580C",Critical:"#DC2626"};
const CENTER=[33.6844,73.0479];

// Unknown types fall back to a neutral "landmark" pin so nothing ever breaks.
const catOf = t => CAT[t] ? t : "landmark";
function pin(cat){const c=CAT[catOf(cat)];return L.divIcon({className:"",html:`<div class="pin" style="background:${c[0]}">${c[1]}</div>`,iconSize:[26,26],iconAnchor:[13,13],popupAnchor:[0,-12]});}

function createMap(id, opt){
  opt = opt || {};
  const kinds = opt.kinds || BASE_KINDS, showRisk = opt.risk !== false;
  const map=L.map(id).setView(opt.center||CENTER,opt.zoom||14);
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(map);
  const groups={};Object.keys(CAT).forEach(k=>groups[k]=L.layerGroup().addTo(map));groups.risk=L.layerGroup().addTo(map);groups.route=L.layerGroup().addTo(map);
  const ov={};kinds.forEach(k=>ov[CAT[k][2]]=groups[k]);if(showRisk)ov["Risk zones"]=groups.risk;ov["Route"]=groups.route;
  L.control.layers(null,ov).addTo(map);
  const lg=L.control({position:"bottomleft"});lg.onAdd=()=>{const d=L.DomUtil.create("div","legend");d.innerHTML=kinds.map(k=>`<div><i style="background:${CAT[k][0]}"></i>${CAT[k][1]} = ${CAT[k][2]}</div>`).join("")+(showRisk?Object.keys(RISK).map(k=>`<div><i class="sq" style="background:${RISK[k]}"></i>${k} risk</div>`).join(""):"");return d;};lg.addTo(map);
  return {map,groups};
}
function addMarkers(m,cat,items,label){m.groups[cat].clearLayers();items.forEach(i=>L.marker([i.lat,i.lng],{icon:pin(cat),title:i.name||i.id}).bindPopup(`<b>${i.name||i.id}</b><br>${label?label(i):i.id}`).addTo(m.groups[cat]));}
function addRisk(m,zones){m.groups.risk.clearLayers();zones.forEach(z=>L.circle([z.lat,z.lng],{radius:z.radius,color:RISK[z.level],fillOpacity:.22,weight:2}).bindPopup(`<b>${z.name}</b><br>${z.level} risk`).addTo(m.groups.risk));}
function drawRoute(m,pts,color,dash){m.groups.route.clearLayers();const l=L.polyline(pts,{color:color||"#2563EB",weight:5,dashArray:dash}).addTo(m.groups.route);m.map.fitBounds(l.getBounds(),{padding:[40,40]});}


function addDemandAreas(m, areas) {
  m.groups.landmark.clearLayers();
  areas.forEach(a => {
    const radius = Math.max(7, Math.min(20, 7 + Math.sqrt(a.population / 10000)));
    L.circleMarker([a.lat, a.lng], {radius, color:"#7C3AED", weight:2, fillColor:"#A78BFA", fillOpacity:.28})
      .bindPopup(`<b>${a.name}</b><br>Estimated population: ${Number(a.population).toLocaleString()}<br><small>Demand area (sample data)</small>`)
      .addTo(m.groups.landmark);
  });
}


// 10 km coverage rings around candidate sites (facility placement map).
function addCoverageCircles(m, sites, km, bestId) {
  if (!m.groups.cover) m.groups.cover = L.layerGroup().addTo(m.map);
  m.groups.cover.clearLayers();
  sites.forEach(c => {
    const best = c.id === bestId;
    L.circle([c.lat, c.lng], {radius: km * 1000, color: best ? "#16A34A" : "#7C3AED", weight: best ? 2.5 : 1.5,
      dashArray: "6 6", fillColor: best ? "#16A34A" : "#7C3AED", fillOpacity: best ? .08 : .04, interactive: false}).addTo(m.groups.cover);
  });
}
