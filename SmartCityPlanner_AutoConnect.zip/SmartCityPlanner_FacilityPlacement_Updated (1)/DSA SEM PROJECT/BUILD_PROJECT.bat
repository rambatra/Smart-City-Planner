@echo off
setlocal
cd /d "%~dp0"
taskkill /F /IM SmartCityPlannerServer.exe >nul 2>nul
where g++ >nul 2>nul
if errorlevel 1 (
    echo MinGW-w64 g++ was not found. Install it and add it to PATH.
    exit /b 1
)
echo Compiling main.cpp...
g++ -std=c++17 -O2 main.cpp -o SmartCityPlannerServer.exe -lws2_32
if errorlevel 1 (
    echo Build failed. See compiler errors above.
    exit /b 1
)
echo Build completed: SmartCityPlannerServer.exe
endlocal
