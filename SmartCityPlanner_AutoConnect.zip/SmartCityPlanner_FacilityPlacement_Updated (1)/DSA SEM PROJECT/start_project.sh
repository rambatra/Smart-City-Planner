#!/usr/bin/env bash
# Smart City Planner - one-click start (Linux / macOS)
# Builds + starts the C++ server if a compiler exists, otherwise opens the page with the built-in engine.
cd "$(dirname "$0")"
open_url() { (command -v xdg-open >/dev/null && xdg-open "$1") || (command -v open >/dev/null && open "$1") || echo "Open this in your browser: $1"; }

pkill -f SmartCityPlannerServer 2>/dev/null; sleep 0.5   # stop any OLD copy still holding port 18080
CXX=$(command -v g++ || command -v clang++)
if [ -n "$CXX" ] && { [ ! -f SmartCityPlannerServer ] || [ main.cpp -nt SmartCityPlannerServer ]; }; then
  echo "Building C++ server because it is missing or main.cpp changed..."
  "$CXX" -std=c++17 -O2 main.cpp -o SmartCityPlannerServer || exit 1
fi
if [ -f SmartCityPlannerServer ]; then
  ./SmartCityPlannerServer & SERVER_PID=$!
  trap 'kill $SERVER_PID 2>/dev/null' EXIT
  sleep 1; open_url "http://localhost:18080/"; wait $SERVER_PID
else
  echo "No C++ compiler found - opening the website with its built-in engine."
  open_url "$PWD/SmartCityPlanner/frontend/index.html"
fi
