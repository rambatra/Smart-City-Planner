@echo off
setlocal
cd /d "%~dp0"
REM Starts the C++ server (and opens the website). Use "START_PROJECT.bat noBrowser" to start only the server.

REM 1) Stop any OLD copy so it cannot keep port 18080 or lock the .exe.
taskkill /F /IM SmartCityPlannerServer.exe >nul 2>nul
timeout /t 1 /nobreak >nul

REM 2) Decide whether the .exe must be (re)built from main.cpp.
set NEEDBUILD=0
if not exist SmartCityPlannerServer.exe set NEEDBUILD=1
if exist SmartCityPlannerServer.exe (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "if ((Get-Item 'main.cpp').LastWriteTime -gt (Get-Item 'SmartCityPlannerServer.exe').LastWriteTime) { exit 1 } else { exit 0 }"
    if errorlevel 1 set NEEDBUILD=1
)

if "%NEEDBUILD%"=="1" (
    where g++ >nul 2>nul
    if errorlevel 1 goto NOCOMPILER
    echo Building C++ server from main.cpp ...
    call BUILD_PROJECT.bat
    if errorlevel 1 goto BUILDFAILED
)
goto RUN

:NOCOMPILER
if exist SmartCityPlannerServer.exe (
    echo g++ not found - using the existing SmartCityPlannerServer.exe
    goto RUN
)
echo No compiler and no SmartCityPlannerServer.exe. The website still works with its built-in engine.
echo To use the C++ server, install MinGW-w64 once and run this file again.
pause
exit /b 1

:BUILDFAILED
if exist SmartCityPlannerServer.exe (
    echo Build failed - starting the previous SmartCityPlannerServer.exe instead.
    goto RUN
)
echo Build failed. See the compiler errors above.
pause
exit /b 1

:RUN
start "Smart City Planner Server" SmartCityPlannerServer.exe
if /I "%~1"=="noBrowser" goto DONE
timeout /t 2 /nobreak >nul
start "" "http://localhost:18080/"
:DONE
endlocal
