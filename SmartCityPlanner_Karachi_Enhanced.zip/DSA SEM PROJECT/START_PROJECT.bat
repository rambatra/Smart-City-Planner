@echo off
REM ==========================================================================
REM  Smart City Planner - one-click start (Windows)
REM  * If a C++ compiler (g++) is installed, the C++ server is built and started.
REM  * If not, the website simply opens and uses its built-in engine.
REM  Either way the project runs - nothing else to set up.
REM ==========================================================================
cd /d "%~dp0"

where g++ >nul 2>nul
if %errorlevel%==0 (
    if not exist SmartCityPlannerServer.exe (
        echo Building C++ server...
        g++ -std=c++17 -O2 main.cpp -o SmartCityPlannerServer.exe -lws2_32
    )
)

if exist SmartCityPlannerServer.exe (
    echo Starting C++ server on http://localhost:18080 ...
    start "Smart City Planner Server" SmartCityPlannerServer.exe
    timeout /t 2 /nobreak >nul
    start "" "http://localhost:18080/"
) else (
    echo C++ compiler not found - opening the website with its built-in engine.
    start "" "%~dp0SmartCityPlanner\frontend\index.html"
)
