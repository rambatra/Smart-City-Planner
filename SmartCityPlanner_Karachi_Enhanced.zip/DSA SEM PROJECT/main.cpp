#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <limits>
#include <cctype>
#include <fstream>
#include <csignal>

#ifdef _WIN32
  #include <winsock2.h>
  #include <ws2tcpip.h>
  #pragma comment(lib, "ws2_32.lib")
  typedef SOCKET SocketType;
  #define CLOSE_SOCKET closesocket
#else
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <sys/time.h>
  #include <unistd.h>
  typedef int SocketType;
  #define INVALID_SOCKET -1
  #define SOCKET_ERROR -1
  #define CLOSE_SOCKET close
#endif

using namespace std;

// ============================================================================
// 1. PURE DSA DATA STRUCTURES (Custom Binary Min-Heap, Graph, Hash Maps)
// ============================================================================

template <typename T>
class CustomMinHeap {
private:
    vector<T> heap;

    void siftUp(int idx) {
        while (idx > 0) {
            int parent = (idx - 1) / 2;
            if (heap[idx] < heap[parent]) {
                swap(heap[idx], heap[parent]);
                idx = parent;
            } else {
                break;
            }
        }
    }

    void siftDown(int idx) {
        int n = (int)heap.size();
        while (true) {
            int smallest = idx;
            int left = 2 * idx + 1;
            int right = 2 * idx + 2;

            if (left < n && heap[left] < heap[smallest]) smallest = left;
            if (right < n && heap[right] < heap[smallest]) smallest = right;

            if (smallest != idx) {
                swap(heap[idx], heap[smallest]);
                idx = smallest;
            } else {
                break;
            }
        }
    }

public:
    bool empty() const { return heap.empty(); }
    size_t size() const { return heap.size(); }

    void push(const T& val) {
        heap.push_back(val);
        siftUp((int)heap.size() - 1);
    }

    T top() const {
        return heap.front();
    }

    void pop() {
        if (heap.empty()) return;
        heap[0] = heap.back();
        heap.pop_back();
        if (!heap.empty()) siftDown(0);
    }
};

struct Location {
    string id;
    string name;
    double lat = 0.0;
    double lng = 0.0;
};

struct Edge {
    string roadId;
    string to;
    double weight; // Distance in km
    bool blocked;
};

struct DijkstraNode {
    double dist;
    string id;
    bool operator<(const DijkstraNode& other) const {
        return dist < other.dist;
    }
};

struct RouteResult {
    bool found = false;
    double totalKm = 0.0;
    int visitedNodes = 0;
    vector<Location> path;
};

struct CandidateSite {
    string id;
    string name;
    string type;
    double lat = 0.0;
    double lng = 0.0;
    double area = 0.0;
    int capacity = 0;
    double suitability = 0.0;

    double computedScore = 0.0;
    double minDistToExisting = 0.0;
    double demandCoverage = 0.0;
};

// ============================================================================
// 2. LIGHTWEIGHT JSON PARSER
// ============================================================================

string extractStringField(const string& obj, const string& key) {
    string pattern = "\"" + key + "\"";
    size_t pos = obj.find(pattern);
    if (pos == string::npos) return "";
    pos = obj.find(':', pos + pattern.size());
    if (pos == string::npos) return "";
    pos = obj.find('"', pos + 1);
    if (pos == string::npos) return "";
    size_t end = pos + 1;
    while (end < obj.size()) {
        if (obj[end] == '"' && obj[end - 1] != '\\') break;
        end++;
    }
    return obj.substr(pos + 1, end - pos - 1);
}

double extractNumberField(const string& obj, const string& key, double def = 0.0) {
    string pattern = "\"" + key + "\"";
    size_t pos = obj.find(pattern);
    if (pos == string::npos) return def;
    pos = obj.find(':', pos + pattern.size());
    if (pos == string::npos) return def;
    pos++;
    while (pos < obj.size() && isspace((unsigned char)obj[pos])) pos++;
    size_t end = pos;
    while (end < obj.size() && (isdigit((unsigned char)obj[end]) || obj[end] == '.' || obj[end] == '-' || obj[end] == 'e' || obj[end] == 'E' || obj[end] == '+')) {
        end++;
    }
    if (end == pos) return def;
    try {
        return stod(obj.substr(pos, end - pos));
    } catch (...) {
        return def;
    }
}

bool extractBoolField(const string& obj, const string& key, bool def = false) {
    string pattern = "\"" + key + "\"";
    size_t pos = obj.find(pattern);
    if (pos == string::npos) return def;
    pos = obj.find(':', pos + pattern.size());
    if (pos == string::npos) return def;
    pos++;
    while (pos < obj.size() && isspace((unsigned char)obj[pos])) pos++;
    if (obj.compare(pos, 4, "true") == 0) return true;
    if (obj.compare(pos, 5, "false") == 0) return false;
    return def;
}

vector<string> extractObjectArray(const string& json, const string& arrayKey) {
    vector<string> objects;
    string pattern = "\"" + arrayKey + "\"";
    size_t pos = json.find(pattern);
    if (pos == string::npos) return objects;
    pos = json.find('[', pos);
    if (pos == string::npos) return objects;

    int depth = 0;
    size_t objStart = string::npos;
    bool inString = false;
    for (size_t i = pos; i < json.size(); ++i) {
        char c = json[i];
        if (c == '"' && (i == 0 || json[i - 1] != '\\')) inString = !inString;
        if (inString) continue;

        if (c == '[') {
            if (depth == 0) depth = 1;
            else depth++;
        } else if (c == ']') {
            depth--;
            if (depth == 0) break;
        } else if (c == '{') {
            if (depth == 1) objStart = i;
            depth++;
        } else if (c == '}') {
            depth--;
            if (depth == 1 && objStart != string::npos) {
                objects.push_back(json.substr(objStart, i - objStart + 1));
                objStart = string::npos;
            }
        }
    }
    return objects;
}

string escapeJson(const string& s) {
    string out;
    for (char c : s) {
        if (c == '"') out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else out += c;
    }
    return out;
}

// ============================================================================
// 3. WEIGHTED CITY GRAPH & DSA ALGORITHMS (BFS, Dijkstra, Path Comparison)
// ============================================================================

class CityGraph {
private:
    // Hash Map for O(1) average-time vertex lookup
    unordered_map<string, Location> nodes;
    // Adjacency List for weighted undirected road graph
    unordered_map<string, vector<Edge>> adjList;

public:
    void addLocation(const Location& loc) {
        nodes[loc.id] = loc;
        if (adjList.find(loc.id) == adjList.end()) {
            adjList[loc.id] = {};
        }
    }

    void addRoad(const string& roadId, const string& u, const string& v, double km, bool blocked) {
        if (nodes.find(u) == nodes.end() || nodes.find(v) == nodes.end()) return;
        if (km < 0.0) return; // Dijkstra requires non-negative edge weights
        adjList[u].push_back({roadId, v, km, blocked});
        adjList[v].push_back({roadId, u, km, blocked});
    }

    bool hasLocation(const string& id) const {
        return nodes.find(id) != nodes.end();
    }

    Location getLocation(const string& id) const {
        return nodes.at(id);
    }

    static double haversineKm(double lat1, double lng1, double lat2, double lng2) {
        const double R = 6371.0;
        const double PI = 3.14159265358979323846;
        double dLat = (lat2 - lat1) * PI / 180.0;
        double dLng = (lng2 - lng1) * PI / 180.0;
        double a = sin(dLat / 2.0) * sin(dLat / 2.0) +
                   cos(lat1 * PI / 180.0) * cos(lat2 * PI / 180.0) *
                   sin(dLng / 2.0) * sin(dLng / 2.0);
        double c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a));
        return R * c;
    }

    // Breadth-First Search (BFS): O(V + E) network connectivity & component count
    struct ConnectivityInfo {
        bool isConnected = true;
        int reachableFromFirst = 0;
        int totalNodes = 0;
        int connectedComponents = 0;
    };

    ConnectivityInfo analyzeConnectivityBFS() const {
        ConnectivityInfo info;
        info.totalNodes = (int)nodes.size();
        if (nodes.empty()) return info;

        unordered_set<string> visited;
        int components = 0;

        for (const auto& kv : nodes) {
            const string& start = kv.first;
            if (visited.count(start)) continue;

            components++;
            int countInComp = 0;
            queue<string> q;
            q.push(start);
            visited.insert(start);

            while (!q.empty()) {
                string u = q.front();
                q.pop();
                countInComp++;

                auto it = adjList.find(u);
                if (it != adjList.end()) {
                    for (const Edge& e : it->second) {
                        if (e.blocked) continue;
                        if (!visited.count(e.to)) {
                            visited.insert(e.to);
                            q.push(e.to);
                        }
                    }
                }
            }

            if (components == 1) {
                info.reachableFromFirst = countInComp;
            }
        }

        info.connectedComponents = components;
        info.isConnected = (components == 1);
        return info;
    }

    // Dijkstra's Shortest Path Algorithm with Custom Binary Min-Heap: O((V + E) log V)
    RouteResult dijkstraShortestPath(const string& startId, const string& endId, const string& ignoreRoadId = "") const {
        RouteResult result;
        if (!hasLocation(startId) || !hasLocation(endId)) return result;

        unordered_map<string, double> dist;
        unordered_map<string, string> parent;

        for (const auto& kv : nodes) {
            dist[kv.first] = numeric_limits<double>::infinity();
        }

        CustomMinHeap<DijkstraNode> minHeap;
        dist[startId] = 0.0;
        minHeap.push({0.0, startId});

        while (!minHeap.empty()) {
            DijkstraNode curr = minHeap.top();
            minHeap.pop();

            if (curr.dist > dist[curr.id]) continue;
            result.visitedNodes++;

            if (curr.id == endId) break;

            auto it = adjList.find(curr.id);
            if (it == adjList.end()) continue;

            for (const Edge& edge : it->second) {
                if (edge.blocked) continue;
                if (!ignoreRoadId.empty() && edge.roadId == ignoreRoadId) continue;

                double newDist = dist[curr.id] + edge.weight;
                if (newDist < dist[edge.to]) {
                    dist[edge.to] = newDist;
                    parent[edge.to] = curr.id;
                    minHeap.push({newDist, edge.to});
                }
            }
        }

        if (dist[endId] == numeric_limits<double>::infinity()) {
            return result;
        }

        // Predecessor-based path reconstruction
        vector<Location> path;
        string curr = endId;
        while (curr != startId) {
            path.push_back(nodes.at(curr));
            curr = parent[curr];
        }
        path.push_back(nodes.at(startId));
        reverse(path.begin(), path.end());

        result.found = true;
        result.totalKm = dist[endId];
        result.path = path;
        return result;
    }

    // Alternative Route Comparison (Edge-Exclusion Shortest Path Discovery)
    vector<RouteResult> findCandidateRoutesForComparison(const string& startId, const string& endId) const {
        vector<RouteResult> routes;
        RouteResult primary = dijkstraShortestPath(startId, endId);
        if (!primary.found) return routes;

        routes.push_back(primary);

        for (size_t i = 0; i + 1 < primary.path.size(); ++i) {
            string u = primary.path[i].id;
            string v = primary.path[i + 1].id;

            string edgeToSkip = "";
            auto it = adjList.find(u);
            if (it != adjList.end()) {
                for (const Edge& e : it->second) {
                    if (!e.blocked && e.to == v) {
                        edgeToSkip = e.roadId;
                        break;
                    }
                }
            }

            if (!edgeToSkip.empty()) {
                RouteResult alt = dijkstraShortestPath(startId, endId, edgeToSkip);
                if (alt.found) {
                    bool duplicate = false;
                    for (const auto& existing : routes) {
                        if (existing.path.size() == alt.path.size()) {
                            bool same = true;
                            for (size_t k = 0; k < alt.path.size(); ++k) {
                                if (existing.path[k].id != alt.path[k].id) {
                                    same = false;
                                    break;
                                }
                            }
                            if (same) { duplicate = true; break; }
                        }
                    }
                    if (!duplicate) {
                        routes.push_back(alt);
                    }
                }
            }
        }

        sort(routes.begin(), routes.end(), [](const RouteResult& a, const RouteResult& b) {
            return a.totalKm < b.totalKm;
        });

        if (routes.size() > 3) routes.resize(3);
        return routes;
    }

    string nearestNodeId(double lat, double lng) const {
        string bestId = "";
        double bestDist = numeric_limits<double>::infinity();
        for (const auto& kv : nodes) {
            double d = haversineKm(lat, lng, kv.second.lat, kv.second.lng);
            if (d < bestDist) {
                bestDist = d;
                bestId = kv.first;
            }
        }
        return bestId;
    }
};

struct CandidateMaxCompare {
    bool operator()(const CandidateSite& a, const CandidateSite& b) const {
        return a.computedScore < b.computedScore;
    }
};

vector<CandidateSite> rankCandidateSites(vector<CandidateSite>& candidates, const vector<Location>& existingFacilities) {
    priority_queue<CandidateSite, vector<CandidateSite>, CandidateMaxCompare> maxHeap;

    for (auto& c : candidates) {
        double minDist = 5.0;
        if (!existingFacilities.empty()) {
            minDist = numeric_limits<double>::infinity();
            for (const auto& ex : existingFacilities) {
                double d = CityGraph::haversineKm(c.lat, c.lng, ex.lat, ex.lng);
                if (d < minDist) minDist = d;
            }
        }
        c.minDistToExisting = minDist;

        double distFactor = min(100.0, (minDist / 3.5) * 100.0);
        double capFactor  = min(100.0, (c.capacity / 600.0) * 100.0);
        double areaFactor = min(100.0, (c.area / 6000.0) * 100.0);

        c.computedScore = (0.45 * c.suitability) +
                          (0.25 * distFactor) +
                          (0.15 * capFactor) +
                          (0.15 * areaFactor);

        c.demandCoverage = (int)min(98.0, round(0.5 * distFactor + 0.5 * capFactor));
        maxHeap.push(c);
    }

    vector<CandidateSite> ranked;
    while (!maxHeap.empty()) {
        ranked.push_back(maxHeap.top());
        maxHeap.pop();
    }
    return ranked;
}

// ============================================================================
// 4. REST API ENDPOINT HANDLERS
// ============================================================================

CityGraph buildGraphFromPayload(const string& body) {
    CityGraph graph;
    auto locObjs = extractObjectArray(body, "locations");
    auto roadObjs = extractObjectArray(body, "roads");

    for (const auto& obj : locObjs) {
        graph.addLocation({
            extractStringField(obj, "id"),
            extractStringField(obj, "name"),
            extractNumberField(obj, "lat"),
            extractNumberField(obj, "lng")
        });
    }
    for (const auto& obj : roadObjs) {
        graph.addRoad(
            extractStringField(obj, "id"),
            extractStringField(obj, "from"),
            extractStringField(obj, "to"),
            extractNumberField(obj, "km"),
            extractBoolField(obj, "blocked")
        );
    }
    return graph;
}

string handleConnectivity(const string& body) {
    CityGraph graph = buildGraphFromPayload(body);
    auto info = graph.analyzeConnectivityBFS();

    ostringstream oss;
    oss << "{\"connected\":" << (info.isConnected ? "true" : "false") << ","
        << "\"reachableNodes\":" << info.reachableFromFirst << ","
        << "\"totalNodes\":" << info.totalNodes << ","
        << "\"components\":" << info.connectedComponents << "}";
    return oss.str();
}

string handleShortestRoute(const string& body) {
    string originId = extractStringField(body, "origin");
    string destId = extractStringField(body, "destination");
    CityGraph graph = buildGraphFromPayload(body);

    RouteResult res = graph.dijkstraShortestPath(originId, destId);

    ostringstream oss;
    oss << fixed << setprecision(4);
    if (!res.found || res.path.empty()) {
        oss << "{\"found\":false,\"totalKm\":0,\"visitedNodes\":" << res.visitedNodes << ",\"path\":[],\"coords\":[]}";
        return oss.str();
    }

    oss << "{\"found\":true,\"totalKm\":" << res.totalKm << ",\"visitedNodes\":" << res.visitedNodes << ",\"path\":[";
    for (size_t i = 0; i < res.path.size(); ++i) {
        if (i > 0) oss << ",";
        oss << "{\"id\":\"" << escapeJson(res.path[i].id) << "\",\"name\":\"" << escapeJson(res.path[i].name) << "\"}";
    }
    oss << "],\"coords\":[";
    for (size_t i = 0; i < res.path.size(); ++i) {
        if (i > 0) oss << ",";
        oss << "[" << res.path[i].lat << "," << res.path[i].lng << "]";
    }
    oss << "]}";
    return oss.str();
}

string handleCompareRoutes(const string& body) {
    string originId = extractStringField(body, "origin");
    string destId = extractStringField(body, "destination");
    CityGraph graph = buildGraphFromPayload(body);

    vector<RouteResult> routes = graph.findCandidateRoutesForComparison(originId, destId);

    ostringstream oss;
    oss << fixed << setprecision(2);
    oss << "{\"routes\":[";
    for (size_t i = 0; i < routes.size(); ++i) {
        if (i > 0) oss << ",";
        string label = (i == 0) ? "Optimal (Dijkstra)" : ("Alternate #" + to_string(i));
        oss << "{"
            << "\"label\":\"" << label << "\","
            << "\"totalKm\":" << routes[i].totalKm << ","
            << "\"hops\":" << (routes[i].path.size() - 1) << ","
            << "\"pathNames\":[";
        for (size_t j = 0; j < routes[i].path.size(); ++j) {
            if (j > 0) oss << ",";
            oss << "\"" << escapeJson(routes[i].path[j].name) << "\"";
        }
        oss << "]}";
    }
    oss << "]}";
    return oss.str();
}


// Candidate records are accepted and maintained by the C++ backend.
vector<CandidateSite> storedCandidates;
bool candidateStoreLoaded = false;

string handleCandidateAdd(const string& body) {
    if (!candidateStoreLoaded) {
        ifstream in("SmartCityPlanner/data/candidate_sites.csv");
        string line;
        while (getline(in, line)) {
            istringstream row(line);
            CandidateSite saved;
            string lat, lng, area, capacity, suitability;
            if (getline(row, saved.id, '|') && getline(row, saved.name, '|') && getline(row, saved.type, '|') &&
                getline(row, lat, '|') && getline(row, lng, '|') && getline(row, area, '|') &&
                getline(row, capacity, '|') && getline(row, suitability, '|')) {
                try { saved.lat=stod(lat); saved.lng=stod(lng); saved.area=stod(area);
                      saved.capacity=stoi(capacity); saved.suitability=stod(suitability);
                      storedCandidates.push_back(saved); } catch (...) {}
            }
        }
        candidateStoreLoaded = true;
    }
    CandidateSite c;
    c.id = extractStringField(body, "id");
    c.name = extractStringField(body, "name");
    c.type = extractStringField(body, "type");
    c.lat = extractNumberField(body, "lat", numeric_limits<double>::quiet_NaN());
    c.lng = extractNumberField(body, "lng", numeric_limits<double>::quiet_NaN());
    c.area = extractNumberField(body, "area");
    c.capacity = (int)extractNumberField(body, "capacity");
    c.suitability = extractNumberField(body, "suitability");
    if (c.id.empty() || c.name.empty() || c.type.empty() || !isfinite(c.lat) || !isfinite(c.lng) ||
        c.lat < 24.0 || c.lat > 25.5 || c.lng < 66.0 || c.lng > 68.0)
        return "{\"ok\":false,\"error\":\"Invalid candidate details or coordinates.\"}";
    for (const auto& old : storedCandidates)
        if (old.id == c.id)
            return "{\"ok\":false,\"error\":\"Candidate ID already exists.\"}";
    storedCandidates.push_back(c);
    ofstream dataFile("SmartCityPlanner/data/candidate_sites.csv", ios::app);
    if (dataFile) dataFile << c.id << '|' << c.name << '|' << c.type << '|' << c.lat << '|' << c.lng << '|'
                          << c.area << '|' << c.capacity << '|' << c.suitability << "\n";
    ostringstream out;
    out << "{\"ok\":true,\"count\":" << storedCandidates.size() << ",\"id\":\"" << escapeJson(c.id) << "\"}";
    return out.str();
}

string handleFacilityAnalyze(const string& body) {
    auto candObjs = extractObjectArray(body, "candidates");
    auto existObjs = extractObjectArray(body, "existing");
    auto areaObjs = extractObjectArray(body, "demandAreas");

    CityGraph graph = buildGraphFromPayload(body);
    vector<CandidateSite> candidates;
    for (const auto& obj : candObjs) {
        CandidateSite c;
        c.id = extractStringField(obj, "id");
        c.name = extractStringField(obj, "name");
        c.type = extractStringField(obj, "type");
        c.lat = extractNumberField(obj, "lat");
        c.lng = extractNumberField(obj, "lng");
        c.area = extractNumberField(obj, "area");
        c.capacity = (int)extractNumberField(obj, "capacity");
        c.suitability = extractNumberField(obj, "suitability");
        candidates.push_back(c);
    }

    vector<Location> existing;
    for (const auto& obj : existObjs) {
        Location loc;
        loc.id = extractStringField(obj, "id");
        loc.name = extractStringField(obj, "name");
        loc.lat = extractNumberField(obj, "lat");
        loc.lng = extractNumberField(obj, "lng");
        existing.push_back(loc);
    }

    struct DemandArea { string name; double lat, lng, population; };
    vector<DemandArea> areas;
    double maxPopulation = 1.0;
    for (const auto& obj : areaObjs) {
        DemandArea a;
        a.name = extractStringField(obj, "name");
        a.lat = extractNumberField(obj, "lat");
        a.lng = extractNumberField(obj, "lng");
        a.population = extractNumberField(obj, "population");
        maxPopulation = max(maxPopulation, a.population);
        areas.push_back(a);
    }

    auto networkDistance = [&](double lat1, double lng1, double lat2, double lng2) {
        string u = graph.nearestNodeId(lat1, lng1);
        string v = graph.nearestNodeId(lat2, lng2);
        if (!u.empty() && !v.empty()) {
            RouteResult path = graph.dijkstraShortestPath(u, v);
            if (path.found) {
                Location fromNode = graph.getLocation(u);
                Location toNode = graph.getLocation(v);
                double firstConnector = CityGraph::haversineKm(lat1, lng1, fromNode.lat, fromNode.lng);
                double lastConnector = CityGraph::haversineKm(lat2, lng2, toNode.lat, toNode.lng);
                return firstConnector + path.totalKm + lastConnector;
            }
        }
        // If the supplied sample graph has no connecting path, use a clearly approximate
        // road-factor estimate rather than reporting an infinite distance.
        return CityGraph::haversineKm(lat1, lng1, lat2, lng2) * 1.25;
    };

    priority_queue<CandidateSite, vector<CandidateSite>, CandidateMaxCompare> maxHeap;
    for (auto& c : candidates) {
        double nearestExisting = existing.empty() ? 8.0 : numeric_limits<double>::infinity();
        for (const auto& ex : existing)
            nearestExisting = min(nearestExisting, networkDistance(c.lat, c.lng, ex.lat, ex.lng));
        c.minDistToExisting = nearestExisting;

        double totalNeed = 0.0, coveredNeed = 0.0, accessTotal = 0.0, accessWeight = 0.0;
        for (const auto& a : areas) {
            double nearestForArea = existing.empty() ? 8.0 : numeric_limits<double>::infinity();
            for (const auto& ex : existing)
                nearestForArea = min(nearestForArea, networkDistance(a.lat, a.lng, ex.lat, ex.lng));
            double populationFactor = a.population / maxPopulation;
            double underservedFactor = 0.35 + 0.65 * min(1.0, nearestForArea / 8.0);
            double need = populationFactor * underservedFactor;
            double d = networkDistance(c.lat, c.lng, a.lat, a.lng);
            totalNeed += a.population * need;
            if (d <= 5.0) coveredNeed += a.population * need;
            accessTotal += (1.0 / (1.0 + d)) * need;
            accessWeight += need;
        }

        double demandScore = totalNeed > 0.0 ? min(100.0, (coveredNeed / totalNeed) * 100.0) : 0.0;
        double accessibility = accessWeight > 0.0 ? min(100.0, (accessTotal / accessWeight) * 100.0) : 0.0;
        double separation = min(100.0, (nearestExisting / 8.0) * 100.0);
        double landScore = min(100.0, 0.55 * c.suitability +
            0.20 * min(100.0, (c.area / 9000.0) * 100.0) +
            0.25 * min(100.0, (c.capacity / 600.0) * 100.0));

        c.demandCoverage = demandScore;
        c.computedScore = 0.40 * demandScore + 0.25 * accessibility +
                          0.20 * separation + 0.15 * landScore;
        maxHeap.push(c);
    }

    vector<CandidateSite> ranked;
    while (!maxHeap.empty()) { ranked.push_back(maxHeap.top()); maxHeap.pop(); }

    ostringstream oss;
    oss << fixed << setprecision(2) << "{\"ranked\":[";
    for (size_t i = 0; i < ranked.size(); ++i) {
        if (i) oss << ",";
        oss << "{\"rank\":" << (i + 1)
            << ",\"id\":\"" << escapeJson(ranked[i].id) << "\""
            << ",\"name\":\"" << escapeJson(ranked[i].name) << "\""
            << ",\"score\":" << ranked[i].computedScore
            << ",\"coverage\":" << ranked[i].demandCoverage
            << ",\"dist\":" << ranked[i].minDistToExisting << "}";
    }
    oss << "]}";
    return oss.str();
}

string handleEvacuation(const string& body) {
    string originId = extractStringField(body, "origin");
    CityGraph graph = buildGraphFromPayload(body);

    size_t sPos = body.find("\"shelter\"");
    string shelterObj = (sPos != string::npos) ? body.substr(sPos) : body;
    double sLat = extractNumberField(shelterObj, "lat");
    double sLng = extractNumberField(shelterObj, "lng");

    string targetNodeId = graph.nearestNodeId(sLat, sLng);
    RouteResult res = graph.dijkstraShortestPath(originId, targetNodeId);

    ostringstream oss;
    oss << fixed << setprecision(4);

    if (!res.found || res.path.empty()) {
        Location startLoc = graph.getLocation(originId);
        double directKm = CityGraph::haversineKm(startLoc.lat, startLoc.lng, sLat, sLng);
        oss << "{\"totalKm\":" << directKm << ",\"hops\":1,\"coords\":[["
            << startLoc.lat << "," << startLoc.lng << "],[" << sLat << "," << sLng << "]]}";
        return oss.str();
    }

    Location lastNode = res.path.back();
    double lastMileKm = CityGraph::haversineKm(lastNode.lat, lastNode.lng, sLat, sLng);
    double totalKm = res.totalKm + lastMileKm;

    oss << "{\"totalKm\":" << totalKm << ",\"hops\":" << res.path.size() << ",\"coords\":[";
    for (size_t i = 0; i < res.path.size(); ++i) {
        if (i > 0) oss << ",";
        oss << "[" << res.path[i].lat << "," << res.path[i].lng << "]";
    }
    oss << ",[" << sLat << "," << sLng << "]]}";
    return oss.str();
}

// ============================================================================
// 5. EMBEDDED CROSS-PLATFORM HTTP SERVER (Port 18080)
// ============================================================================

void sendAll(SocketType client, const string& data);

void sendHttpResponse(SocketType client, int statusCode, const string& statusText, const string& jsonBody) {
    ostringstream res;
    res << "HTTP/1.1 " << statusCode << " " << statusText << "\r\n"
        << "Content-Type: application/json\r\n"
        << "Access-Control-Allow-Origin: *\r\n"
        << "Access-Control-Allow-Methods: POST, GET, OPTIONS\r\n"
        << "Access-Control-Allow-Headers: Content-Type\r\n"
        << "Content-Length: " << jsonBody.size() << "\r\n"
        << "Connection: close\r\n\r\n"
        << jsonBody;
    sendAll(client, res.str());
}


// ---- Serves the web frontend too, so ONE program (this server) runs the whole project ----
string toLowerStr(string s) {
    for (auto& ch : s) ch = (char)tolower((unsigned char)ch);
    return s;
}

string mimeType(const string& path) {
    size_t dot = path.rfind('.');
    string ext = (dot == string::npos) ? "" : toLowerStr(path.substr(dot + 1));
    if (ext == "html") return "text/html; charset=utf-8";
    if (ext == "css")  return "text/css; charset=utf-8";
    if (ext == "js")   return "application/javascript; charset=utf-8";
    if (ext == "json") return "application/json; charset=utf-8";
    if (ext == "png")  return "image/png";
    if (ext == "jpg" || ext == "jpeg") return "image/jpeg";
    if (ext == "gif")  return "image/gif";
    if (ext == "svg")  return "image/svg+xml";
    if (ext == "ico")  return "image/x-icon";
    return "application/octet-stream";
}

void sendAll(SocketType client, const string& data) {
    size_t sent = 0;
    while (sent < data.size()) {
        int n = (int)send(client, data.c_str() + sent, (int)(data.size() - sent), 0);
        if (n <= 0) break;
        sent += (size_t)n;
    }
}

string findFrontendDir(int argc, char** argv) {
    vector<string> candidates;
    if (argc > 1) candidates.push_back(argv[1]);
    candidates.push_back("SmartCityPlanner/frontend");
    candidates.push_back("../SmartCityPlanner/frontend");
    candidates.push_back("../../SmartCityPlanner/frontend");
    candidates.push_back("frontend");
    candidates.push_back("../frontend");
    for (const auto& dir : candidates) {
        ifstream f(dir + "/index.html");
        if (f.good()) return dir;
    }
    return "";
}

bool serveStaticFile(SocketType client, const string& frontendDir, string urlPath) {
    if (frontendDir.empty()) return false;
    size_t q = urlPath.find('?');
    if (q != string::npos) urlPath = urlPath.substr(0, q);
    if (urlPath == "/" || urlPath.empty()) urlPath = "/index.html";
    if (urlPath.find("..") != string::npos) return false;      // block path traversal

    ifstream file(frontendDir + urlPath, ios::binary);
    if (!file.good()) return false;
    string content((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());

    ostringstream head;
    head << "HTTP/1.1 200 OK\r\n"
         << "Content-Type: " << mimeType(urlPath) << "\r\n"
         << "Content-Length: " << content.size() << "\r\n"
         << "Cache-Control: no-cache\r\n"
         << "Connection: close\r\n\r\n";
    sendAll(client, head.str());
    sendAll(client, content);
    return true;
}

int main(int argc, char** argv) {
#ifdef _WIN32
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "WSAStartup failed.\n";
        return 1;
    }
#endif

#ifndef _WIN32
    signal(SIGPIPE, SIG_IGN);   // do not crash if a browser closes a connection early
#endif
    const int PORT = 18080;
    const string frontendDir = findFrontendDir(argc, argv);
    SocketType serverSock = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSock == INVALID_SOCKET) {
        cerr << "Failed to create socket.\n";
        return 1;
    }

    int opt = 1;
    setsockopt(serverSock, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(PORT);

    if (bind(serverSock, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR) {
        cerr << "Bind failed on port " << PORT << ". Is another instance running?\n";
        CLOSE_SOCKET(serverSock);
        return 1;
    }

    if (listen(serverSock, 10) == SOCKET_ERROR) {
        cerr << "Listen failed.\n";
        CLOSE_SOCKET(serverSock);
        return 1;
    }

    cout << "====================================================\n";
    cout << "  SMART CITY PLANNER - C++17 DSA BACKEND ENGINE\n";
    cout << "  DSA: Adjacency List Graph, Hash Map, Custom MinHeap,\n";
    cout << "       BFS Connectivity, Dijkstra Shortest Path, MaxHeap\n";
    cout << "  Listening on: http://localhost:" << PORT << "\n";
    if (!frontendDir.empty())
        cout << "  Website     : http://localhost:" << PORT << "/   (opens the project)\n";
    else
        cout << "  (frontend folder not found - open SmartCityPlanner/frontend/index.html manually)\n";
    cout << "====================================================\n";

    while (true) {
        SocketType client = accept(serverSock, nullptr, nullptr);
        if (client == INVALID_SOCKET) continue;

        // A browser may open an idle "pre-connect" socket and send nothing. Without a timeout the
        // single-threaded server would wait on it forever and look "not connected". Give up after 1 s.
#ifdef _WIN32
        DWORD tmo = 1000;
        setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tmo, sizeof(tmo));
#else
        timeval tmo{1, 0};
        setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tmo, sizeof(tmo));
#endif

        string rawRequest;
        char buf[4096];
        int bytesRead = 0;

        while ((bytesRead = recv(client, buf, sizeof(buf), 0)) > 0) {
            rawRequest.append(buf, bytesRead);
            if (rawRequest.find("\r\n\r\n") != string::npos) break;
        }

        size_t headerEnd = rawRequest.find("\r\n\r\n");
        if (headerEnd == string::npos) {
            CLOSE_SOCKET(client);
            continue;
        }

        string headers = rawRequest.substr(0, headerEnd);
        string body = rawRequest.substr(headerEnd + 4);

        size_t contentLength = 0;
        size_t clPos = toLowerStr(headers).find("content-length:");
        if (clPos != string::npos) {
            try { contentLength = stoul(headers.substr(clPos + 15)); } catch (...) { contentLength = 0; }
        }
        while (body.size() < contentLength && (bytesRead = recv(client, buf, sizeof(buf), 0)) > 0) {
            body.append(buf, bytesRead);
        }

        istringstream lineStream(headers);
        string method, path;
        lineStream >> method >> path;

        cout << "[" << method << "] " << path << "\n";

        if (method == "OPTIONS") {
            sendHttpResponse(client, 200, "OK", "{}");
        } else if (method == "GET" && path == "/api/health") {
            sendHttpResponse(client, 200, "OK", "{\"status\":\"ok\",\"engine\":\"C++17\"}");
        } else if (method == "GET" && serveStaticFile(client, frontendDir, path)) {
            // website file served
        } else if (method == "POST" && path == "/api/route/shortest") {
            sendHttpResponse(client, 200, "OK", handleShortestRoute(body));
        } else if (method == "POST" && path == "/api/route/compare") {
            sendHttpResponse(client, 200, "OK", handleCompareRoutes(body));
        } else if (method == "POST" && path == "/api/route/connectivity") {
            sendHttpResponse(client, 200, "OK", handleConnectivity(body));
        } else if (method == "POST" && path == "/api/facility/candidate/add") {
            sendHttpResponse(client, 200, "OK", handleCandidateAdd(body));
        } else if (method == "POST" && path == "/api/facility/analyze") {
            sendHttpResponse(client, 200, "OK", handleFacilityAnalyze(body));
        } else if (method == "POST" && path == "/api/emergency/evacuate") {
            sendHttpResponse(client, 200, "OK", handleEvacuation(body));
        } else {
            sendHttpResponse(client, 404, "Not Found", "{\"error\":\"Endpoint not found\"}");
        }

        CLOSE_SOCKET(client);
    }

    CLOSE_SOCKET(serverSock);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
