# Smart City Planner — Web Interface + C++17 DSA Engine

## Quick start (any laptop)
**Easiest:** double-click `index.html` in the project folder (or `SmartCityPlanner/frontend/index.html`).
Everything works immediately. No server, no `.exe`, no install.

**Optional, to use the C++ backend:** double-click `START_PROJECT.bat` (Windows) or run `./start_project.sh` (Linux/macOS).
It compiles `main.cpp` if `g++` is installed, starts the server on port 18080 and opens `http://localhost:18080/`.
The page detects the server automatically; the Route Optimizer shows which engine is active
(`Engine: C++ server (port 18080)` or `Engine: Built-in`).

## How the "server not connected" problem was fixed
1. `main.cpp` had a syntax error (`nodes.at(startId])`) so the server could never be built. Fixed.
2. The frontend now has a built-in JavaScript copy of the same algorithms (`js/engine.js`).
   If port 18080 is unreachable it is used automatically, so no error appears and nothing has to be started.
3. The C++ server now also serves the website itself and answers `/api/health`.
4. Leaflet is bundled locally (`lib/leaflet`). Only the map background tiles need internet.

## Architecture
- **Frontend**: HTML5, CSS3, JavaScript, Leaflet + OpenStreetMap tiles (`SmartCityPlanner/frontend/`).
- **Backend engine**: C++17 DSA code (`main.cpp`), mirrored by `js/engine.js` for offline use.
- **Data**: `SmartCityPlanner/data/*.json` (reference copy) and `js/data.js` (used by the app).

## Route Optimizer: Cities
Pick a **City** (Islamabad, Karachi, Lahore, Rawalpindi), then an origin and destination
(dropdown or click two markers) to get the shortest path inside that city, compare alternatives,
and block/unblock roads. City data lives in `js/data.js` under `cities` (also in `data/cities.json`);
to add a city copy one block and change the id prefix, name, centre and places.
Coordinates are approximate and road lengths are estimated (straight line × 1.3), for academic demonstration.

## Map markers
Each place has a `type`, and the marker letter follows it: **H** hospital, **S** school/university,
**F** fire station, **M** market/mall, **T** station/airport, **P** park, **L** landmark
(plus the original C clinic, + candidate, ■ shelter, ! incident).

## C++ DSA concepts (`main.cpp`)
1. Weighted undirected graph (adjacency list) + `unordered_map` hash table for O(1) vertex lookup.
2. Custom binary min-heap (`CustomMinHeap<T>`, `siftUp` / `siftDown`).
3. Dijkstra's shortest path, O((V+E) log V), predecessor path reconstruction, blocked-road avoidance.
4. BFS, O(V+E), connectivity and connected components.
5. Alternative route comparison by edge exclusion.
6. Max-heap ranking of facility candidate sites + Haversine distance.

## Manual build
```bash
g++ -std=c++17 main.cpp -o SmartCityPlannerServer -lws2_32   # Windows (MinGW)
g++ -std=c++17 main.cpp -o SmartCityPlannerServer            # Linux / macOS
```
or `cmake -B build && cmake --build build`.

## Smart Facility Placement — Karachi pilot

The Facility Placement page now uses its own Karachi dataset and does not overwrite the Route Optimizer or Emergency Planner datasets.

- **Neighbourhood demand areas:** 10 sample Karachi localities with illustrative population estimates.
- **Existing facilities:** sample hospitals, schools, fire stations and a clinic, stored separately by category.
- **Candidate plots:** 5 initial hospital-site options; administrators can add, edit and delete candidate plots.
- **Road network:** uses the current Karachi demonstration graph from `SAMPLE.cities.karachi`.
- **C++ calculation:** the `/api/facility/analyze` endpoint snaps places to the road graph, uses Dijkstra for network distances where a path exists, estimates a road distance when the supplied sample graph is disconnected, calculates underserved-population coverage and accessibility, and ranks candidates with a max-heap using a transparent weighted score.
- **Browser fallback:** `frontend/js/engine.js` retains fallback calculations for the existing route/emergency workflows. Facility ranking and candidate creation are C++-only and require the server.
- **Storage:** candidate records are saved in browser `localStorage` under `scp-karachi-facility-v2`; new candidate creation is also validated and stored by the C++ server in `SmartCityPlanner/data/candidate_sites.csv`. Use **Reset Karachi data** to restore the starter sample (the C++ candidate history file is separate).

**Data limitation:** the included Karachi neighbourhood populations, facility inventory and road graph are illustrative academic sample data, not a complete or official census, OpenStreetMap extract, land registry or confirmation that a plot is vacant/available. Candidate coordinates are administrator-supplied possible sites. The module ranks those options; it does not automatically discover legally available land.


### Facility placement updates
- Candidate place names are geocoded through the OpenStreetMap Nominatim search service; internet access is required. A location outside the Karachi pilot bounds or a name with no match is rejected instead of using the default map coordinates.
- Every candidate receives a unique `KCS` ID and its own map marker. Candidate creation and facility ranking require the C++ server; JavaScript handles the form, geocoding request and Leaflet rendering only.
- Karachi starter data now has 20 reference entries in each supported category: hospitals, schools/universities, fire stations, clinics and shelters. Some records use approximate neighbourhood reference coordinates and are intended for academic demonstration, not as an authoritative directory.
