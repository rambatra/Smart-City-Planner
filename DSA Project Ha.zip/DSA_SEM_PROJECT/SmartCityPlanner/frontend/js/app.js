// Navigation, pages, forms and C++ Backend API integration.
let D = structuredClone(SAMPLE);
const M = {};
let recId = null;

const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const pill = t => `<span class="pill ${esc(t)}">${esc(t)}</span>`;

function toast(msg, kind) {
  const t = document.createElement("div");
  t.className = "toast " + (kind || "");
  t.textContent = msg;
  $("#toasts").append(t);
  setTimeout(() => t.remove(), 3400);
}

function table(el, cols, rows, actions) {
  $(el).innerHTML =
    "<thead><tr>" + cols.map(c => `<th>${c[0]}</th>`).join("") + (actions ? "<th>Actions</th>" : "") + "</tr></thead><tbody>" +
    (rows.length
      ? rows.map(r => `<tr class="${r._cls || ""}">` + cols.map(c => `<td>${c[1](r)}</td>`).join("") + (actions ? `<td>${actions(r)}</td>` : "") + "</tr>").join("")
      : `<tr><td colspan="${cols.length + 1}">No records match. Adjust the filters or add a record.</td></tr>`) +
    "</tbody>";
}

function closeModal() { $("#modal").classList.add("hidden"); }
function showModal(title, fn) {
  $("#m-t").textContent = title;
  $("#m-f").innerHTML = "";
  fn($("#m-f"));
  $("#modal").classList.remove("hidden");
}
function info(title, obj) {
  showModal(title, f => {
    f.innerHTML = Object.entries(obj).map(([k, v]) => `<div class="full"><b>${esc(k)}:</b> ${esc(v)}</div>`).join("") +
      `<div class="acts"><button type="button" class="btn" id="mc">Close</button></div>`;
    $("#mc").onclick = closeModal;
  });
}
function confirmBox(msg, yes) {
  showModal("Please confirm", f => {
    f.innerHTML = `<div class="full">${esc(msg)}</div><div class="acts"><button type="button" class="btn ghost" id="mn">Cancel</button><button type="button" class="btn red" id="my">Confirm</button></div>`;
    $("#mn").onclick = closeModal;
    $("#my").onclick = () => { closeModal(); yes(); };
  });
}
function openForm(title, fields, vals, save) {
  showModal(title, f => {
    f.innerHTML = fields.map(x => `<label class="${x.full ? "full" : ""}">${x.label}${
      x.opts
        ? `<select name="${x.k}">${x.opts.map(o => `<option${o == vals[x.k] ? " selected" : ""}>${o}</option>`).join("")}</select>`
        : `<input name="${x.k}" type="${x.num ? "number" : "text"}" step="any" value="${esc(vals[x.k] ?? "")}"${x.ro ? " readonly" : ""}>`
    }<span class="err"></span></label>`).join("") +
      `<div class="acts"><button type="button" class="btn ghost" id="mn">Cancel</button><button class="btn">Save</button></div>`;
    $("#mn").onclick = closeModal;
    f.onsubmit = e => {
      e.preventDefault();
      let ok = true, out = {};
      fields.forEach(x => {
        const el = f.elements[x.k], err = el.parentNode.querySelector(".err");
        let v = el.value.trim(), m = "";
        if (x.req && !v) m = "Required.";
        else if (x.num && v !== "") {
          v = Number(v);
          if (isNaN(v)) m = "Enter a number.";
          else if ((x.min != null && v < x.min) || (x.max != null && v > x.max)) m = `Must be ${x.min} to ${x.max}.`;
        }
        err.textContent = m;
        if (m) ok = false;
        out[x.k] = v;
      });
      if (ok) { closeModal(); save(out); }
    };
  });
}

// ---------- navigation ----------
const PAGES = {
  dashboard: "Dashboard",
  facility: "Smart Facility Placement",
  route: "Smart Route Optimizer",
  emergency: "Emergency & Disaster Planner",
  settings: "Settings"
};
function go(p) { if (!PAGES[p]) p = "dashboard"; location.hash = p; }
function show() {
  const p = PAGES[location.hash.slice(1)] ? location.hash.slice(1) : "dashboard";
  document.querySelectorAll(".page").forEach(x => x.classList.toggle("hidden", x.id !== "p-" + p));
  document.querySelectorAll("#nav a").forEach(a => a.classList.toggle("on", a.dataset.p === p));
  $("#title").textContent = PAGES[p];
  $("#crumb").textContent = p === "dashboard" ? "Overview" : "Dashboard / " + PAGES[p];
  $("#side").classList.remove("open");
  $("#scrim").classList.remove("on");
  ({ dashboard: initDash, facility: initFac, route: initRoute, emergency: initEm })[p]?.();
  setTimeout(() => Object.values(M).forEach(m => m.map.invalidateSize()), 60);
  window.scrollTo(0, 0);
}
const opts = (arr, f) => arr.map(f).join("");

// ---------- dashboard ----------
function stats(el, items) {
  $(el).innerHTML = items.map(i => `<div class="stat" title="${i[3] || ""}" style="--c:${i[2]}"><b>${i[0]}</b><span>${i[1]}</span><small>${i[3] || ""}</small></div>`).join("");
}
function initDash() {
  stats("#stats", [
    [D.facilities.length, "Total facilities", "#2563EB", "Existing hospitals, schools, fire stations and clinics"],
    [D.candidates.length, "Candidate locations", "#7C3AED", "Empty sites being considered for a new facility"],
    [D.roads.length, "Road connections", "#0D9488", "Roads linking city places, used for routes"],
    [D.incidents.filter(i => i.status !== "Resolved").length, "Active incidents", "#DC2626", "Emergencies that are not resolved yet"],
    [D.shelters.filter(s => s.status !== "Closed").length, "Available shelters", "#16A34A", "Safe places that can still take people in"],
    [D.riskZones.length, "Risk zones", "#F59E0B", "Areas marked as dangerous, such as flood zones"]
  ]);
  $("#today").textContent = new Date().toLocaleDateString(undefined, { dateStyle: "full" });
  $("#mods").innerHTML = [
    ["facility", "Smart Facility Placement", "Identify suitable locations for public facilities based on demand, accessibility, and existing infrastructure.", "#2563EB"],
    ["route", "Smart Route Optimizer", "Explore efficient routes between city locations using an intelligent road-network planning system.", "#0D9488"],
    ["emergency", "Emergency & Disaster Planner", "Explore incident management, risk-zone visualization, and evacuation planning.", "#DC2626"]
  ].map(m => `<div class="mod" style="--c:${m[3]}"><h3>${m[1]}</h3><p>${m[2]}</p><button class="btn" data-go="${m[0]}">Explore module</button></div>`).join("");
  $("#activity").innerHTML = D.activity.map(a => `<li><div><b>${a[0]}</b><small>${a[1]}</small></div><div>${pill(a[3])}<small>${a[2]}</small></div></li>`).join("");
  if (!M.dash) { M.dash = createMap("m-dash"); }
  const m = M.dash;
  ["hospital", "school", "fire", "clinic"].forEach(t => addMarkers(m, t, D.facilities.filter(f => f.type === t), f => "Facility " + f.id));
  addMarkers(m, "candidate", D.candidates, c => `${c.id}, ${c.type} candidate`);
  addMarkers(m, "shelter", D.shelters, s => `${s.available}/${s.capacity} spaces`);
  addMarkers(m, "incident", D.incidents, i => `${i.type}, ${i.severity}`);
  addRisk(m, D.riskZones);
}

// ---------- facility placement (Karachi pilot; C++ Dijkstra + weighted ranking) ----------
let FAC = loadFacilityData();
function loadFacilityData() {
  try {
    const saved = localStorage.getItem("scp-karachi-facility-v3");
    if (saved) {
      const data = JSON.parse(saved);
      data.demandAreas = structuredClone(KARACHI_FACILITY_DATA.demandAreas);   // neighbourhoods are fixed reference data
      return data;
    }
  } catch (e) {}
  return structuredClone(KARACHI_FACILITY_DATA);
}
function saveFacilityData() {
  try { localStorage.setItem("scp-karachi-facility-v3", JSON.stringify(FAC)); } catch (e) {}
}
const FAC_FIELDS = [
  { k: "id", label: "Site ID", ro: 1 },
  { k: "name", label: "Candidate plot / area name (search real place name)", req: 1 },
  { k: "lat", label: "Latitude (optional: leave blank to search by name)", num: 1, min: 24, max: 25.5 },
  { k: "lng", label: "Longitude (optional: leave blank to search by name)", num: 1, min: 66, max: 68 },
  { k: "type", label: "Facility category", opts: ["hospital", "school", "fire", "clinic", "shelter"] },
  { k: "area", label: "Available area (m²)", num: 1, req: 1, min: 1 },
  { k: "capacity", label: "Planned capacity", num: 1, req: 1, min: 1 },
  { k: "suitability", label: "Site suitability (0-100)", num: 1, req: 1, min: 0, max: 100 }
];
function initFac() {
  if (!M.fac) {
    M.fac = createMap("m-fac", {center: FAC.center || [24.87,67.05], zoom: 11, kinds:["hospital","school","fire","clinic","candidate","landmark"], risk:false});
    $("#f-cat").innerHTML = opts(["hospital", "school", "fire", "clinic", "shelter"], c => `<option>${c}</option>`);
    $("#f-cat").value = "hospital";
  }
  renderFac();
}
function renderFac() {
  const cat = $("#f-cat").value, m = M.fac, cs = FAC.candidates.filter(c => c.type === cat);
  const existing = FAC.facilities.filter(f => f.type === cat);
  $("#f-exist").textContent = `${existing.length} existing ${cat} facilities`;
  stats("#f-data-stats", [
    [FAC.demandAreas.length, "Neighbourhoods", "#7C3AED", "Areas with estimated population"],
    [FAC.facilities.length, "Existing facilities", "#DC2626", "Already-built example facilities"],
    [FAC.locations.length, "Road-network points", "#0D9488", "Intersections and key places in this pilot graph"],
    [cs.length, `Candidate plots (${cat})`, "#2563EB", "Possible locations being compared in this category"]
  ]);
  table("#f-tbl", [
    ["ID", c => c.id], ["Candidate plot", c => esc(c.name)], ["Lat", c => Number(c.lat).toFixed(4)], ["Lng", c => Number(c.lng).toFixed(4)],
    ["Area m²", c => c.area], ["Capacity", c => c.capacity], ["Suitability", c => c.suitability + "%"]
  ], cs.map(c => ({ ...c, _cls: c.id === recId ? "best" : "" })),
  c => `<button class="btn ghost sm" data-fa="view" data-id="${esc(c.id)}">View</button> <button class="btn ghost sm" data-fa="edit" data-id="${esc(c.id)}">Edit</button> <button class="btn ghost sm" data-fa="del" data-id="${esc(c.id)}">Delete</button>`);
  ["hospital", "school", "fire", "clinic"].forEach(t => addMarkers(m, t, FAC.facilities.filter(f => f.type === t && t === cat), f => `${f.name}<br>Existing ${cat}`));
  addMarkers(m, "shelter", cat === "shelter" ? FAC.facilities.filter(f => f.type === "shelter") : []);
  // Candidate plots belong only to the currently selected facility category.
  addMarkers(m, "candidate", cs, c => `${c.id}${c.id === recId ? " (Top Recommendation)" : ""}<br>${esc(c.name)}<br>${esc(c.type)} · Capacity ${c.capacity}`);
  addDemandAreas(m, FAC.demandAreas);
  addCoverageCircles(m, cs, COVERAGE_RADIUS_KM, recId);   // 10 km service area around each candidate
  const pts = [...FAC.demandAreas, ...existing, ...cs];
  if (pts.length) m.map.fitBounds(L.latLngBounds(pts.map(c => [c.lat, c.lng])).pad(.12));
}
async function geocodeKarachiPlace(placeName) {
  const q = encodeURIComponent(placeName + ", Karachi, Sindh, Pakistan");
  const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=pk&q=${q}`;
  const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 10000);
  let response, matches;
  try {
    response = await fetch(url, { headers: { "Accept": "application/json" }, signal: ctrl.signal });
    if (!response.ok) throw new Error("status " + response.status);
    matches = await response.json();
  } catch (e) {
    throw new Error("Map search service could not be reached. Check your internet, or type the Latitude and Longitude yourself and save again.");
  } finally { clearTimeout(timer); }
  if (!matches.length) throw new Error("Location not found. Try a more complete place name.");
  const hit = matches[0], lat = Number(hit.lat), lng = Number(hit.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < 24 || lat > 25.5 || lng < 66 || lng > 68)
    throw new Error("The matched place is outside the Karachi pilot area.");
  return { lat, lng, displayName: hit.display_name };
}
function candForm(c) {
  const nw = !c;
  const nextId = () => "KCS" + Date.now().toString();
  openForm(nw ? "Add Karachi candidate site" : "Edit candidate site", FAC_FIELDS,
    c || { id: nextId(), type: $("#f-cat").value, suitability: 75, area: 5000, capacity: 300, lat: "", lng: "" },
    async v => {
      try {
        if (nw) {
          // Use typed coordinates if both are given, otherwise resolve the place name (never a default point).
          if (v.lat !== "" && v.lng !== "") {
            v.geocodedAddress = "Entered manually";
          } else {
            const found = await geocodeKarachiPlace(v.name);
            v.lat = found.lat; v.lng = found.lng; v.geocodedAddress = found.displayName;
          }
          // C++ owns candidate creation and rejects duplicate IDs/invalid coordinates.
          await apiAddCandidate(v);
          FAC.candidates.push(v);
        } else {
          if (v.lat === "" || v.lng === "") { delete v.lat; delete v.lng; }
          Object.assign(c, v);
        }
        saveFacilityData();
        toast(nw ? `Candidate added at ${Number(v.lat).toFixed(5)}, ${Number(v.lng).toFixed(5)}.` : "Candidate plot updated.", "good");
        recId = null; $("#f-res").classList.add("hidden"); renderFac();
        const marker = FAC.candidates.find(x => x.id === v.id);
        if (marker && M.fac) M.fac.map.setView([marker.lat, marker.lng], 15);
      } catch (err) { toast(err.message || "Could not add candidate site.", "bad"); }
    });
}
async function facRun() {
  const cat = $("#f-cat").value;
  const cs = FAC.candidates.filter(c => c.type === cat);
  if (!cs.length) return toast("Add a candidate plot for this category first.", "bad");
  try {
    const res = await API.analyzeFacilities({
      category: cat, candidates: cs, existing: FAC.facilities.filter(f => f.type === cat),
      demandAreas: FAC.demandAreas, locations: FAC.locations, roads: FAC.roads
    });
    const ranked = res.ranked || [];
    if (!ranked.length) return toast("No ranking was returned. Check the candidate and network data.", "bad");
    recId = ranked[0].id;
    table("#f-rtbl", [
      ["Rank", c => c.rank], ["Candidate plot", c => esc(c.name)], ["Score / 100", c => Number(c.score).toFixed(1)],
      [`Demand covered (≤ ${res.radiusKm} km)`, c => Number(c.coverage).toFixed(1) + "%"],
      [`Areas within ${res.radiusKm} km`, c => `${c.coveredAreas} / ${res.totalAreas}`], ["Nearest existing (road km)", c => Number(c.dist).toFixed(2)],
      ["Verdict", c => c.rank === 1 ? pill("Recommended") : ""]
    ], ranked.map(c => ({ ...c, _cls: c.rank === 1 ? "best" : "" })));
    $("#f-res").classList.remove("hidden"); renderFac();
    $("#f-eng").textContent = res.engine === "C++ Engine" ? "Calculated by your C++ server (localhost:18080)." : res.note;
    toast(`Ranked using ${res.engine} (${res.radiusKm} km coverage radius, Dijkstra + weighted score + max-heap).`, "good");
  } catch (err) { toast("Could not analyse the sites: " + err.message, "bad"); }
}


// ---------- Route Optimizer extras: more hospitals/schools + real-road drawing (OSRM) ----------
// Extra hospitals/schools per city (Karachi ones come from the Facility Placement dataset). Coordinates approximate.
const ROUTE_EXTRA_PLACES = {
  islamabad: [
    ["PIMS Hospital","hospital",33.7058,73.0537],["Shifa International Hospital","hospital",33.6930,73.0780],
    ["Poly Clinic Hospital","hospital",33.7020,73.0450],["Maroof International Hospital","hospital",33.7100,73.0380],
    ["Quaid-i-Azam University","school",33.7480,73.1370],["NUST University","school",33.6420,72.9930],
    ["COMSATS University","school",33.6500,73.1550],["Islamabad Model College","school",33.6780,73.0600],
    ["Bahria University Islamabad","school",33.7160,73.0700]
  ],
  lahore: [
    ["Mayo Hospital","hospital",31.5753,74.3306],["Services Hospital","hospital",31.5368,74.3305],
    ["Jinnah Hospital","hospital",31.4829,74.2987],["Shaukat Khanum Hospital","hospital",31.4687,74.4046],
    ["Sheikh Zayed Hospital","hospital",31.4570,74.3310],
    ["LUMS","school",31.4700,74.4110],["University of the Punjab","school",31.4967,74.3025],
    ["Government College University","school",31.5586,74.3294],["FC College University","school",31.5203,74.3333],
    ["UET Lahore","school",31.5788,74.3556]
  ],
  rawalpindi: [
    ["Holy Family Hospital","hospital",33.6293,73.0636],["Benazir Bhutto Hospital","hospital",33.6135,73.0490],
    ["Combined Military Hospital","hospital",33.5990,73.0620],["Rawalpindi Institute of Cardiology","hospital",33.6330,73.0735],
    ["Fatima Jinnah Women University","school",33.5990,73.0470],["Arid Agriculture University","school",33.6490,73.0830],
    ["Government College Satellite Town","school",33.6420,73.0650],["Army Public School Rawalpindi","school",33.6000,73.0300]
  ]
};
function routeKm(a, b) {   // haversine
  const R = 6371, t = x => x * Math.PI / 180, dLa = t(b.lat - a.lat), dLo = t(b.lng - a.lng);
  const h = Math.sin(dLa / 2) ** 2 + Math.cos(t(a.lat)) * Math.cos(t(b.lat)) * Math.sin(dLo / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
function ensureRouteExtras(id) {
  const c = D.cities[id];
  if (!c || c._extras) return;
  c._extras = true;
  const locs = [...c.locations], roads = [...c.roads];   // copies: other modules keep their own arrays
  let list = (ROUTE_EXTRA_PLACES[id] || []).map(p => ({ name: p[0], type: p[1], lat: p[2], lng: p[3] }));
  if (id === "karachi" && typeof KARACHI_FACILITY_DATA !== "undefined")
    list = KARACHI_FACILITY_DATA.facilities.filter(f => f.type === "hospital" || f.type === "school")
      .map(f => ({ name: f.name, type: f.type, lat: f.lat, lng: f.lng }));
  const pref = (locs[0].id.match(/^[A-Za-z]+/) || ["X"])[0] + "X";
  let n = 1, rn = 1;
  list.forEach(p => {
    if (locs.some(l => l.name === p.name || (l.type === p.type && routeKm(l, p) < 0.15))) return;   // skip duplicates
    const node = { id: pref + String(n++).padStart(2, "0"), name: p.name, type: p.type, lat: p.lat, lng: p.lng };
    locs.slice().sort((a, b) => routeKm(a, node) - routeKm(b, node)).slice(0, 3).forEach(near => {
      roads.push({ id: pref.replace("X", "R") + "X" + String(rn++).padStart(2, "0"), from: node.id, to: near.id,
        km: Math.round(routeKm(near, node) * 1.3 * 10) / 10, blocked: false });
    });
    locs.push(node);
  });
  c.locations = locs; c.roads = roads;
}
async function fetchRoadRoute(path) {   // real driving road geometry through the Dijkstra stops (OSRM)
  const pts = path.map(p => p.lng + "," + p.lat).join(";");
  const r = await fetch(`https://router.project-osrm.org/route/v1/driving/${pts}?overview=full&geometries=geojson&steps=true`);
  if (!r.ok) throw new Error("OSRM " + r.status);
  const j = await r.json();
  if (j.code !== "Ok" || !j.routes.length) throw new Error("no road route");
  const rt = j.routes[0], names = [];
  rt.legs.forEach(l => l.steps.forEach(s => { if (s.name && s.distance > 50 && names[names.length - 1] !== s.name) names.push(s.name); }));
  return { coords: rt.geometry.coordinates.map(c => [c[1], c[0]]), km: rt.distance / 1000, min: rt.duration / 60, names };
}

// ---------- route (Graph + BFS Connectivity + Dijkstra's Shortest Path + Path Comparison, per CITY) ----------
let routeCity = "islamabad";                       // city currently selected in the Route Optimizer
const RC = () => D.cities[routeCity];              // {name, center, zoom, locations, roads}
const LN = id => RC().locations.find(l => l.id === id) || D.locations.find(l => l.id === id);
const typeName = t => TYPE_LABEL[catOf(t)] || CAT[catOf(t)][2];
const eng = () => BACKEND.mode === "cpp" ? "C++ Engine" : "Built-in Engine";
let routeClickTurn = "origin";

function renderRouteMarkers() {
  const m = M.route;
  ROUTE_KINDS.forEach(k => m.groups[k].clearLayers());
  RC().locations.forEach(loc => {
    const kind = catOf(loc.type);
    const marker = L.marker([loc.lat, loc.lng], { icon: pin(kind), title: loc.name })
      .bindPopup(() => `<b>${esc(loc.name)}</b> (${esc(loc.id)})<br>${esc(typeName(loc.type))}<br><small>Click marker to select as ${routeClickTurn}</small>`);
    marker.on("click", () => {
      if (routeClickTurn === "origin") {
        $("#r-o").value = loc.id;
        routeClickTurn = "destination";
        toast(`Origin set to ${loc.name}. Now click destination marker.`);
      } else {
        if ($("#r-o").value === loc.id) {
          toast("Destination must differ from origin.", "bad");
          return;
        }
        $("#r-d").value = loc.id;
        routeClickTurn = "origin";
        toast(`Destination set to ${loc.name}. Calculating route...`);
        routeGo();
      }
    });
    marker.addTo(m.groups[kind]);
  });
}

function fillRouteSelects() {
  const o = opts(RC().locations, l => `<option value="${l.id}">${esc(l.name)} (${l.id})</option>`);
  $("#r-o").innerHTML = '<option value="">Select origin</option>' + o;
  $("#r-d").innerHTML = '<option value="">Select destination</option>' + o;
}

function renderCityInfo() {
  const c = RC(), counts = {};
  c.locations.forEach(l => { const k = catOf(l.type); counts[k] = (counts[k] || 0) + 1; });
  const parts = Object.keys(counts).map(k => `${CAT[k][2]}: ${counts[k]}`).join(" · ");
  const blocked = c.roads.filter(r => r.blocked).length;
  $("#r-city-info").innerHTML = `<b>${esc(c.name)}</b>: ${c.locations.length} places [${esc(parts)}] · ${c.roads.length} roads${blocked ? `, ${blocked} blocked` : ""}.`;
  $("#r-map-title").innerHTML = `Map: ${esc(c.name)} <small>(Click markers to pick Origin/Destination)</small>`;
}

function resetRouteResults() {
  routeClickTurn = "origin";
  M.route.groups.route.clearLayers();
  $("#r-cmp-card").style.display = "none";
  $("#r-res").innerHTML = '<h3>Route results</h3><p class="note">Choose an origin and destination (or click two markers on the map), then calculate.</p>';
}

function setRouteCity(id) {
  routeCity = D.cities[id] ? id : "islamabad";
  ensureRouteExtras(routeCity);
  $("#r-city").value = routeCity;
  fillRouteSelects();
  resetRouteResults();
  const c = RC();
  M.route.map.setView(c.center, c.zoom);
  renderRouteMarkers();
  renderRoads();
  renderCityInfo();
  updateConnectivityBadge();
}

function initRoute() {
  ensureRouteExtras(routeCity);
  if (!M.route) {
    M.route = createMap("m-route", { kinds: ROUTE_KINDS, risk: false });
    $("#r-city").innerHTML = opts(Object.keys(D.cities), id => `<option value="${id}">${esc(D.cities[id].name)}</option>`);
    setRouteCity(routeCity);
  } else {
    renderRouteMarkers();
    renderRoads();
    renderCityInfo();
    updateConnectivityBadge();
  }
  updateEngineBadge();
}

function updateEngineBadge() {
  const cpp = BACKEND.mode === "cpp";
  const txt = cpp ? "Engine: C++ server (port 18080)" : BACKEND.mode === "js" ? "Engine: Built-in (no server needed)" : "Engine: checking…";
  const b = $("#r-eng");
  b.textContent = txt;
  b.className = "pill " + (cpp ? "Open" : "info");
  $("#s-engine").textContent = cpp ? "C++ server connected on localhost:18080" : BACKEND.mode === "js" ? "Built-in engine (C++ server not running, not required)" : "checking…";
}

async function updateConnectivityBadge() {
  try {
    const res = await API.checkConnectivity({
      locations: RC().locations,
      roads: RC().roads
    });
    const badge = $("#r-net-badge");
    if (res.connected) {
      badge.className = "pill Open";
      badge.textContent = `BFS: Network Connected (${res.reachableNodes}/${res.totalNodes} nodes)`;
    } else {
      badge.className = "pill Blocked";
      badge.textContent = `BFS: Disconnected (${res.components} components)`;
    }
    updateEngineBadge();
  } catch (e) {
    $("#r-net-badge").textContent = "Connectivity check failed";
  }
}

const ROAD_SEARCH_LIMIT = 12;
// Road-closure search: every word typed must match the road ID, either end-point name or the km value (any order).
function roadMatches(r, q) {
  const hay = `${r.id} ${LN(r.from).name} ${LN(r.to).name} ${r.km} ${r.blocked ? "blocked" : "open"}`.toLowerCase();
  return q.toLowerCase().split(/\s+|\bto\b|[-↔–,]+/).filter(Boolean).every(t => hay.includes(t));
}

function renderRoads() {
  const q = ($("#r-rq") ? $("#r-rq").value : "").trim();
  const all = RC().roads;
  let rows, msg;
  if (!q) {
    // No search yet: don't dump the whole list, only show roads that are currently blocked so they can be reopened.
    rows = all.filter(r => r.blocked);
    msg = rows.length
      ? `Showing ${rows.length} currently blocked road(s). Type above to search among ${all.length} roads.`
      : `${all.length} roads available. Type above to search a road to block.`;
  } else {
    const found = all.filter(r => roadMatches(r, q));
    rows = found.slice(0, ROAD_SEARCH_LIMIT);
    msg = found.length > rows.length
      ? `${found.length} roads match; showing first ${rows.length}. Type more to narrow down.`
      : `${found.length} road(s) match "${q}".`;
  }
  if ($("#r-rq-info")) $("#r-rq-info").textContent = msg;
  table("#r-tbl", [
    ["Road", r => r.id],
    ["Connection", r => `${esc(LN(r.from).name)} ↔ ${esc(LN(r.to).name)}`],
    ["Km", r => r.km],
    ["Status", r => pill(r.blocked ? "Blocked" : "Open")]
  ], rows, r => `<button class="btn ghost sm" data-rd="${r.id}">${r.blocked ? "Unblock" : "Block"}</button>`);
  const empty = $("#r-tbl tbody td[colspan]");
  if (empty) empty.textContent = q ? "No road matches your search." : "No blocked roads. Search above to find a road to block.";
}

async function routeGo() {
  const o = $("#r-o").value, d = $("#r-d").value;
  if (!o || !d) return toast("Select both an origin and a destination.", "bad");
  if (o === d) return toast("Origin and destination must differ.", "bad");

  try {
    const res = await API.calculateRoute({
      origin: o,
      destination: d,
      locations: RC().locations,
      roads: RC().roads
    });
    if (!res.found) {
      M.route.groups.route.clearLayers();
      $("#r-res").innerHTML = `<h3>Route results</h3><p class="bad"><b>No valid route found!</b> BFS/Dijkstra confirmed no open path exists between ${esc(LN(o).name)} and ${esc(LN(d).name)}.</p>`;
      return toast("No open path available between selected locations.", "bad");
    }
    drawRoute(M.route, res.coords, "#94A3B8", "6 8");   // straight-line fallback until real roads load
    let road = null;
    try {
      road = await fetchRoadRoute(res.path);
      M.route.groups.route.clearLayers();
      const line = L.polyline(road.coords, { color: "#2563EB", weight: 6, opacity: .9 }).addTo(M.route.groups.route);
      res.path.forEach((p, i) => L.circleMarker([p.lat, p.lng], { radius: 7, color: "#fff", weight: 2, fillColor: i === 0 ? "#16A34A" : i === res.path.length - 1 ? "#DC2626" : "#2563EB", fillOpacity: 1 })
        .bindTooltip(`${i + 1}. ${p.name}`).addTo(M.route.groups.route));
      M.route.map.fitBounds(line.getBounds(), { padding: [40, 40] });
    } catch (e) { toast("Real road layer unavailable (internet needed); showing straight link.", "bad"); }
    const blockedCount = RC().roads.filter(r => r.blocked).length;
    $("#r-res").innerHTML = `<h3>Route results: ${esc(RC().name)} (${eng()} · Dijkstra)</h3>
      <p><b>${res.totalKm.toFixed(2)} km</b> optimal shortest path · <b>${res.path.length - 1}</b> road segment(s) · <b>${res.visitedNodes}</b> nodes explored</p>
      ${road ? `<p><b>Actual road distance: ${road.km.toFixed(1)} km</b> · about ${Math.round(road.min)} min by car</p>
      ${road.names.length ? `<p><b>Roads to follow:</b> ${road.names.map(esc).join(" → ")}</p>` : ""}` : ""}
      <ol>${res.path.map(p => `<li>${esc(p.name)} (${esc(p.id)})</li>`).join("")}</ol>
      ${blockedCount ? `<p class="note">${blockedCount} blocked road(s) excluded from graph traversal.</p>` : ""}`;
    toast(`Shortest path in ${RC().name} computed by ${eng()}!`, "good");
    updateEngineBadge();
  } catch (err) {
    toast("Could not calculate the route: " + err.message, "bad");
  }
}

async function routeCompare() {
  const o = $("#r-o").value, d = $("#r-d").value;
  if (!o || !d) return toast("Select both an origin and a destination first.", "bad");
  if (o === d) return toast("Origin and destination must differ.", "bad");

  try {
    const res = await API.compareRoutes({
      origin: o,
      destination: d,
      locations: RC().locations,
      roads: RC().roads
    });
    const card = $("#r-cmp-card");
    if (!res.routes || !res.routes.length) {
      card.style.display = "none";
      return toast("No routes available to compare.", "bad");
    }
    card.style.display = "block";
    table("#r-ctbl", [
      ["Option", r => r.label],
      ["Distance", r => r.totalKm.toFixed(2) + " km"],
      ["Segments", r => r.hops],
      ["Path", r => r.pathNames.map(esc).join(" → ")]
    ], res.routes.map((r, i) => ({ ...r, _cls: i === 0 ? "best" : "" })));
    toast(`Compared ${res.routes.length} route option(s) via ${eng()}.`, "good");
    updateEngineBadge();
  } catch (err) {
    toast("Could not compare routes: " + err.message, "bad");
  }
}

function routeClear() {
  $("#r-o").value = $("#r-d").value = "";
  resetRouteResults();
  toast("Route cleared.");
}

// ---------- emergency (C++ Priority Queue Incident Triage + Dijkstra Evacuation) ----------
const INC_FIELDS = () => [
  { k: "id", label: "Incident ID", ro: 1 },
  { k: "type", label: "Incident type", req: 1 },
  { k: "location", label: "Location", opts: D.locations.map(l => l.name) },
  { k: "severity", label: "Severity", opts: ["Critical", "High", "Medium", "Low"] },
  { k: "time", label: "Reported time", req: 1 },
  { k: "affected", label: "Affected population", num: 1, req: 1, min: 0 },
  { k: "status", label: "Status", opts: ["Open", "Responding", "Resolved"] }
];
function initEm() {
  if (!M.em) {
    M.em = createMap("m-em");
    M.evac = createMap("m-evac");
    $("#v-a").innerHTML = opts(D.locations, l => `<option value="${l.id}">${l.name}</option>`);
  }
  renderEm();
}
function renderEm() {
  const m = M.em;
  stats("#e-stats", [
    [D.incidents.length, "Total incidents", "#2563EB", "All reported emergencies"],
    [D.incidents.filter(i => i.severity === "Critical").length, "Critical incidents", "#DC2626", "Most urgent emergencies"],
    [D.riskZones.filter(z => z.level === "High" || z.level === "Critical").length, "High-risk zones", "#EA580C", "Areas with high or critical danger"],
    [D.shelters.filter(s => s.status !== "Closed").length, "Available shelters", "#16A34A", "Safe places that can still take people in"],
    [D.incidents.filter(i => i.status !== "Resolved").reduce((s, i) => s + i.affected, 0).toLocaleString(), "Estimated affected", "#F59E0B", "People affected by unresolved incidents"]
  ]);
  addRisk(m, D.riskZones);
  addMarkers(m, "incident", D.incidents, i => `${i.type}, ${i.severity}<br>${i.status}`);
  addMarkers(m, "shelter", D.shelters, s => `${s.available}/${s.capacity} free`);
  table("#s-tbl", [
    ["Shelter", s => esc(s.name)], ["Location", s => esc(s.location)],
    ["Capacity", s => s.capacity], ["Available", s => s.available], ["Status", s => pill(s.status)]
  ], D.shelters);
  $("#v-s").innerHTML = opts(D.shelters.filter(s => s.status !== "Closed" && s.available > 0), s => `<option value="${s.id}">${s.name} (${s.available} free)</option>`);
  addMarkers(M.evac, "shelter", D.shelters);
  renderInc();
}
function renderInc() {
  const q = $("#i-q").value.toLowerCase(), sv = $("#i-sev").value, st = $("#i-st").value;
  table("#i-tbl", [
    ["ID", i => i.id], ["Type", i => esc(i.type)], ["Location", i => esc(i.location)],
    ["Severity", i => pill(i.severity)], ["Time", i => i.time], ["Status", i => pill(i.status)]
  ], D.incidents.filter(i => (!sv || i.severity === sv) && (!st || i.status === st) && (!q || (i.id + i.type + i.location).toLowerCase().includes(q))),
  i => `<button class="btn ghost sm" data-ia="view" data-id="${i.id}">View</button> <button class="btn ghost sm" data-ia="edit" data-id="${i.id}">Edit</button> <button class="btn ghost sm" data-ia="st" data-id="${i.id}">Update status</button>`);
}
function incForm(i) {
  const nw = !i, now = new Date().toISOString().slice(0, 16).replace("T", " ");
  openForm(nw ? "Report incident" : "Edit incident", INC_FIELDS(),
    i || { id: "INC-" + (100 + D.incidents.length + 1), time: now, severity: "Medium", status: "Open", affected: 0 },
    v => {
      const loc = D.locations.find(l => l.name === v.location);
      Object.assign(v, { lat: loc.lat, lng: loc.lng });
      if (nw) {
        if (D.incidents.some(x => x.id === v.id)) return toast("Incident ID already exists.", "bad");
        D.incidents.unshift(v);
      } else Object.assign(i, v);
      toast(nw ? "Incident reported." : "Incident updated.", "good");
      renderEm();
    });
}
async function evacGo() {
  const a = LN($("#v-a").value), s = D.shelters.find(x => x.id === $("#v-s").value);
  if (!a || !s) return toast("Select an affected location and an available shelter.", "bad");

  try {
    const res = await API.planEvacuation({
      origin: a.id,
      shelter: s,
      locations: D.locations,
      roads: D.roads
    });
    drawRoute(M.evac, res.coords, "#DC2626", "8 8");
    $("#v-res").innerHTML = `<p><b>Evacuation Plan (${eng()}):</b> ${esc(a.name)} → ${esc(s.name)} (<b>${res.totalKm.toFixed(2)} km</b> via ${res.hops} road hops, ${s.available} spaces free). Blocked roads automatically avoided.</p>`;
    toast(`Evacuation path calculated via ${eng()}!`, "good");
  } catch (err) {
    toast("Could not plan the evacuation: " + err.message, "bad");
  }
}

// ---------- wiring ----------
function resetAll() { D = structuredClone(SAMPLE); recId = null; if (M.route) setRouteCity(routeCity); $("#f-res").classList.add("hidden"); show(); toast("Sample data restored.", "good"); }
function start() { $("#intro").classList.add("out"); $("#app").classList.remove("hidden"); setTimeout(() => $("#intro").remove(), 700); show(); }
document.addEventListener("DOMContentLoaded", () => {
  const t = setTimeout(start, 3600);
  $("#skip").onclick = () => { clearTimeout(t); start(); };
  addEventListener("hashchange", show);
  $("#tog").onclick = () => {
    if (innerWidth <= 800) { $("#side").classList.toggle("open"); $("#scrim").classList.toggle("on"); }
    else { $("#side").classList.toggle("min"); setTimeout(() => Object.values(M).forEach(m => m.map.invalidateSize()), 250); }
  };
  $("#scrim").onclick = () => { $("#side").classList.remove("open"); $("#scrim").classList.remove("on"); };
  $("#bell").onclick = () => toast(BACKEND.mode === "cpp" ? "Connected to the C++ DSA server on localhost:18080." : "Running on the built-in DSA engine (C++ server not needed).");
  $("#gsearch").onkeydown = e => {
    if (e.key !== "Enter") return;
    const q = e.target.value.toLowerCase(), k = {
      facility: ["facil", "site", "hospital", "school", "clinic"],
      route: ["route", "road", "path"],
      emergency: ["emerg", "incident", "shelter", "risk", "evac", "disaster"],
      dashboard: ["dash", "home"]
    };
    const hit = Object.keys(k).find(p => k[p].some(w => q.includes(w)));
    hit ? go(hit) : toast("No matching module. Try route, facility, or shelter.", "bad");
  };
  document.body.addEventListener("click", e => {
    const b = e.target.closest("button");
    if (!b) return;
    if (b.dataset.go) go(b.dataset.go);
    if (b.dataset.expand) {
      const el = document.getElementById(b.dataset.expand), big = el.classList.toggle("big");
      b.textContent = big ? "Close map" : "Expand map";
      Object.values(M).forEach(m => m.map.invalidateSize());
    }
    const id = b.dataset.id;
    if (b.dataset.fa) {
      const c = FAC.candidates.find(x => x.id === id);
      if (!c) return;
      if (b.dataset.fa === "view") info("Candidate plot " + c.id, c);
      if (b.dataset.fa === "edit") candForm(c);
      if (b.dataset.fa === "del") confirmBox(`Delete ${c.name}?`, () => { FAC.candidates = FAC.candidates.filter(x => x !== c); saveFacilityData(); recId = null; $("#f-res").classList.add("hidden"); renderFac(); toast("Candidate plot deleted.", "good"); });
    }
    if (b.dataset.rd) {
      const r = RC().roads.find(x => x.id === b.dataset.rd);
      r.blocked = !r.blocked;
      renderRoads();
      updateConnectivityBadge();
      toast(`${r.id} ${r.blocked ? "blocked" : "reopened"}.`);
      if ($("#r-o").value && $("#r-d").value && $("#r-o").value !== $("#r-d").value) {
        routeGo();
        if ($("#r-cmp-card").style.display === "block") routeCompare();
      }
    }
    if (b.dataset.ia) {
      const i = D.incidents.find(x => x.id === id);
      if (b.dataset.ia === "view") info(i.id, { Type: i.type, Location: i.location, Severity: i.severity, Time: i.time, Affected: i.affected, Status: i.status });
      if (b.dataset.ia === "edit") incForm(i);
      if (b.dataset.ia === "st") {
        const o = ["Open", "Responding", "Resolved"];
        i.status = o[(o.indexOf(i.status) + 1) % 3];
        renderEm();
        toast(`${i.id} is now ${i.status}.`, "good");
      }
    }
  });
  $("#f-cat").onchange = () => { recId = null; $("#f-res").classList.add("hidden"); renderFac(); };
  $("#f-add").onclick = () => candForm();
  $("#f-run").onclick = facRun;
  $("#f-reset").onclick = () => confirmBox("Restore the original Karachi facility-placement sample data?", () => { localStorage.removeItem("scp-karachi-facility-v3"); FAC = structuredClone(KARACHI_FACILITY_DATA); recId = null; $("#f-res").classList.add("hidden"); renderFac(); toast("Karachi facility data restored.", "good"); });
  $("#s-reset").onclick = resetAll;
  $("#r-city").onchange = () => { setRouteCity($("#r-city").value); toast(`City changed to ${RC().name}.`, "good"); };
  BACKEND.onChange(updateEngineBadge);
  probeBackend().then(updateEngineBadge);
  $("#r-rq").oninput = renderRoads;
  $("#r-rq-x").onclick = () => { $("#r-rq").value = ""; renderRoads(); $("#r-rq").focus(); };
  $("#r-go").onclick = routeGo;
  $("#r-cmp").onclick = routeCompare;
  $("#r-clr").onclick = routeClear;
  $("#r-sw").onclick = () => { const o = $("#r-o"), d = $("#r-d"), t = o.value; o.value = d.value; d.value = t; };
  $("#i-add").onclick = () => incForm();
  ["#i-q", "#i-sev", "#i-st"].forEach(s => $(s).oninput = renderInc);
  $("#v-go").onclick = evacGo;
  $("#qa-f").onclick = () => { go("facility"); setTimeout(() => candForm(), 100); };
  $("#qa-r").onclick = () => go("route");
  $("#qa-i").onclick = () => { go("emergency"); setTimeout(() => incForm(), 100); };
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      closeModal();
      document.querySelectorAll(".map.big").forEach(m => m.classList.remove("big"));
      document.querySelectorAll("[data-expand]").forEach(b => b.textContent = "Expand map");
    }
  });
});
