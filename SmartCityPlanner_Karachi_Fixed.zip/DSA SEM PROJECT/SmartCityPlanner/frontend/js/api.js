// ----------------------------------------------------------------------------
// API layer. Most legacy modules retain their original fallback.
// Facility ranking and candidate creation are C++-only and never run in JS.
// ----------------------------------------------------------------------------
// When this page is served BY the C++ server, use same-origin; otherwise localhost:18080
const API_BASE = (location.port === "18080" && location.protocol.startsWith("http"))
  ? "/api"
  : "http://localhost:18080/api";

const BACKEND = {
  mode: "unknown",          // "cpp" | "js" | "unknown"
  lastFail: 0,
  retryMs: 15000,           // after a failure, wait this long before trying C++ again
  listeners: [],
  label() { return this.mode === "cpp" ? "C++ Engine" : "Built-in Engine"; },
  set(mode) {
    if (mode === this.mode) return;
    this.mode = mode;
    this.listeners.forEach(f => { try { f(mode); } catch (e) { /* ignore */ } });
  },
  onChange(f) { this.listeners.push(f); }
};

async function fetchJson(url, opts, timeoutMs) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { ...opts, signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } finally { clearTimeout(timer); }
}

// Quick check at start-up: is the C++ server there?
async function probeBackend() {
  try {
    const j = await fetchJson(API_BASE + "/health", {}, 2500);
    BACKEND.set(j && j.status === "ok" ? "cpp" : "js");
  } catch (e) { BACKEND.set("js"); BACKEND.lastFail = Date.now(); }
  return BACKEND.mode;
}

async function apiPost(path, body) {
  const tryCpp = BACKEND.mode !== "js" || Date.now() - BACKEND.lastFail > BACKEND.retryMs;
  if (tryCpp) {
    try {
      const out = await fetchJson(API_BASE + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      }, 4000);
      BACKEND.set("cpp");
      return out;
    } catch (e) {
      BACKEND.lastFail = Date.now();
      BACKEND.set("js");
    }
  }
  return Engine.handle(path, body);   // identical algorithms, runs in the browser
}

const API = {
  analyzeFacilities: async p => {
    try {
      const out = await fetchJson(API_BASE + "/facility/analyze", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(p)
      }, 12000);
      BACKEND.set("cpp");
      return out;
    } catch (e) {
      throw new Error("C++ backend is not reachable. Close this page and start the project using START_PROJECT.bat, then open http://localhost:18080/. Details: " + (e.message || "connection failed"));
    }
  },
  calculateRoute:    p => apiPost("/route/shortest", p),
  compareRoutes:     p => apiPost("/route/compare", p),
  checkConnectivity: p => apiPost("/route/connectivity", p),
  setRoadStatus:     p => apiPost("/route/roads/status", p),
  rankIncidents:     p => apiPost("/emergency/rank", p),
  planEvacuation:    p => apiPost("/emergency/evacuate", p)
};


// Candidate creation is deliberately C++-only: no JavaScript algorithm fallback.
async function apiAddCandidate(candidate) {
  const out = await fetchJson(API_BASE + "/facility/candidate/add", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(candidate)
  }, 7000);
  if (!out.ok) throw new Error(out.error || "C++ backend rejected the candidate.");
  BACKEND.set("cpp");
  return out;
}
