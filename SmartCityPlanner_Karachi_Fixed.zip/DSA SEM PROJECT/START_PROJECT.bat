@echo off
REM Smart City Planner - build and launch the C++ backend + frontend.
cd /d "%~dp0"

where g++ >nul 2>nul
if %errorlevel%==0 (
    echo Building C++ server from main.cpp...
    g++ -std=c++17 -O2 main.cpp -o SmartCityPlannerServer.exe -lws2_32
    if errorlevel 1 (
        echo.
        echo Build failed. Check the compiler errors above.
        pause
        exit /b 1
    )
)

if exist SmartCityPlannerServer.exe (
    echo Starting C++ server on http://localhost:18080 ...
    start "Smart City Planner Server" SmartCityPlannerServer.exe
    timeout /t 2 /nobreak >nul
    start "" "http://localhost:18080/"
) else (
    echo C++ compiler and prebuilt server were not found.
    echo Install MinGW-w64 g++ and run this file again.
    pause
)
